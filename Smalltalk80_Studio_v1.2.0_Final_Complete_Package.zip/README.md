# Smalltalk-80 Studio 1.2.0 Final

Open `Smalltalk80_Studio_v1.2.0_Final.html` from disk and choose **Enter Studio**. The application and illustrated HTML guide run offline in modern desktop and tablet browsers. See the guide for the Workspace, projects, images, SIF, and staged file transfer.

- `RELEASE_NOTES.md` summarizes the 1.2 branch and records the release qualification.
- `IMPLEMENTATION_NOTES.md` records draft evidence, supported behavior, and known gaps.
- `reports/` includes automated results and the 27-area requirements matrix.
- `samples/` includes Smalltalk source, SIF, Studio projects, and migration fixtures.
- `SHA256SUMS.txt` identifies the exact files in this release.
- `COPYING` contains the application license. `LICENSE_MIT.txt` accompanies components distributed under MIT.

From the extracted folder, run `node tests/test_runtime.cjs --emit-sif-evidence`, `node tests/test_runtime.cjs --qualification`, `python3 tests/check_sif_interchange.py`, and `python3 tests/audit_standalone.py`. The optional browser harness uses Python Playwright and a local Chromium executable.
