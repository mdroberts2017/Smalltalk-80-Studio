!studio-package 1
!manifest {"id":"studio.samples.pixel-pad","version":"1.0.0","title":"Pixel Pad","requires":{"studio":"1.1","classes":["Object","Form"]}}
!class PixelPad < Object | bitmap
!method instance
reset
  bitmap := Form width: 32 height: 20.
  ^ bitmap
!
!method instance
displayForm
  ^ bitmap
!
!method instance
pointerX: column y: row
  | ink |
  column < 0 ifTrue: [ ^ 0 ]. row < 0 ifTrue: [ ^ 0 ].
  column >= 32 ifTrue: [ ^ 0 ]. row >= 20 ifTrue: [ ^ 0 ].
  ink := 1 - (bitmap atX: column y: row).
  bitmap atX: column y: row put: ink.
  ^ ink
!
!method instance
invert
  bitmap invert.
  ^ bitmap countBlack
!
!method instance
inkCount
  ^ bitmap countBlack
!
!method class
start
  | app |
  app := self new. app reset.
  ^ app
!
!startup PixelPad start
