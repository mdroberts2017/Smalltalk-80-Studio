"""Record static asset dependencies without treating navigation links as resources."""
from html.parser import HTMLParser
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
APP = ROOT / 'Smalltalk80_Studio_v1.2.0_Final.html'
EXPECTED = '3eb0f8a40624298e0f0afc36e8d5393760d0b048b5d5f4977480ff3417b48756'

class Resources(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.loads = []
        self.styles = []
        self.in_style = False

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if tag == 'style':
            self.in_style = True
        if 'style' in attrs:
            self.styles.append(attrs['style'])
        keys = ('src', 'srcset', 'poster', 'data', 'href')
        resource_tags = {'audio', 'embed', 'iframe', 'image', 'img', 'link',
                         'object', 'script', 'source', 'track', 'use', 'video'}
        if tag in resource_tags:
            for key in keys:
                if attrs.get(key):
                    self.loads.append((tag + ':' + key, attrs[key]))

    def handle_endtag(self, tag):
        if tag == 'style':
            self.in_style = False

    def handle_data(self, text):
        if self.in_style:
            self.styles.append(text)

data = APP.read_bytes()
digest = hashlib.sha256(data).hexdigest()
assert digest == EXPECTED, 'The accepted executable changed'
parser = Resources()
parser.feed(data.decode('utf-8'))
for style in parser.styles:
    for value in re.findall(r"""url\(\s*(['"]?)(.*?)\1\s*\)""", style, flags=re.I):
        parser.loads.append(('css:url', value[1]))
    for value in re.findall(r"""@import\s+['"]([^'"]+)['"]""", style, flags=re.I):
        parser.loads.append(('css:import', value))
external = [(attr, value) for attr, value in parser.loads if not value.lower().startswith(('data:', '#'))]
assert not external, external
report = {'milestone': 'Final', 'executable': APP.name, 'sha256': digest,
          'declared_resources_checked': len(parser.loads), 'external_or_local_dependencies': external,
          'scope': 'Static markup and CSS resource audit'}
(ROOT / 'reports/Final_Static_Assets.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
