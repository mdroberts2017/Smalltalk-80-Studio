"""Independently check draft SIF chunk framing and selected fixture declarations."""
from pathlib import Path
import json
import re

ROOT = Path(__file__).resolve().parents[1]
TOKEN = re.compile(r"!!|!|[^!]+")
HEADER = "Smalltalk interchangeVersion: '1.0'"
CLASS = re.compile(
    r"Class named: '([A-Za-z_]\w*)'\s+superclass: '([A-Za-z_]\w*)'"
    r"\s+indexedInstanceVariables: #'(none|object|byte)'"
    r"\s+instanceVariableNames: '[^']*'\s+classVariableNames: '[^']*'"
    r"\s+sharedPools: '[^']*'\s+classInstanceVariableNames: '[^']*'"
)


def decode(path):
    chunks = []
    parts = []
    for m in TOKEN.finditer(path.read_text(encoding='utf-8')):
        token = m.group()
        if token == '!':
            chunks.append(''.join(parts).strip())
            parts.clear()
        else:
            parts.append('!' if token == '!!' else token)
    if ''.join(parts).strip():
        raise ValueError(f'{path.name}: unterminated chunk')
    if not chunks or chunks[0] != HEADER:
        raise ValueError(f'{path.name}: missing version 1.0 header')
    return chunks


def layouts(chunks):
    found = []
    for chunk in chunks:
        if chunk.startswith('Class named:'):
            match = CLASS.fullmatch(chunk)
            if not match:
                raise ValueError('Invalid class declaration')
            found.append(match.groups())
    return found


expectations = {
    'SifLedger': [
        ('SifLedger', 'Object', 'none'),
        ('SifChildLedger', 'SifLedger', 'none'),
    ],
    'SifIndexed': [
        ('IndexedRecord', 'Object', 'object'),
        ('IndexedRecordChild', 'IndexedRecord', 'none'),
        ('IndexedOctets', 'Object', 'byte'),
        ('IndexedOctetsChild', 'IndexedOctets', 'none'),
    ],
}
results = []
for name, expected in expectations.items():
    source = decode(ROOT / 'samples' / (name + '.sif'))
    exported = decode(ROOT / 'reports' / (name + '.export.sif'))
    assert source == exported, f'{name}: export altered the chunk sequence'
    assert layouts(exported) == expected, f'{name}: unexpected class layouts'
    if name == 'SifLedger':
        assert any("^ 'Ready!'" in chunk for chunk in exported)
        assert exported.index("LedgerSettings initializerFor: 'Step'") < exported.index('Global initializer')
    results.append({'fixture': name, 'chunks': len(exported), 'classes': layouts(exported), 'status': 'pass'})

report = {'scope': 'Independent Python structural reader, no Smalltalk execution', 'fixtures': results}
(ROOT / 'reports/Final_SIF_Structural_Interchange.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
