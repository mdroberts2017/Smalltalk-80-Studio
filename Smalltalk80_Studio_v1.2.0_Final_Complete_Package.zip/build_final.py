"""Promote the checksum-verified RC2 standalone to 1.2.0 Final."""
from hashlib import sha256
from pathlib import Path
import sys

root = Path(__file__).resolve().parent
baseline = Path(sys.argv[1]) if len(sys.argv) > 1 else (
    root.parent / 'rc2_120/Smalltalk80_Studio_v1.2.0-rc.2_RC2.html'
)
data = baseline.read_bytes()
assert sha256(data).hexdigest() == '30c027523d78117f91a488b31f9d23cc7e3b5b5de1113936bf0adffb49ac07f1'
text = (data.decode('utf-8')
        .replace('1.2.0-rc.2', '1.2.0')
        .replace('1.2 RC2', '1.2 Final')
        .replace('· RC2', '· Final')
        .replace('_RC2_', '_Final_')
        .replace("phase:'A6.4'", "phase:'Final'")
        .replace('RC2 freezes the accepted A6.3 runtime for A6.4 draft qualification.',
                 'Version 1.2.0 Final incorporates the runtime accepted in RC2. Qualification used NCITS J20 draft revision 1.9, with documented deviations.'))
(root / 'Smalltalk80_Studio_v1.2.0_Final.html').write_bytes(text.encode('utf-8'))
