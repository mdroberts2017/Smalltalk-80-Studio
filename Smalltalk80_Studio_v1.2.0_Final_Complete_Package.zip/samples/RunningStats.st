!studio-package 1
!manifest {"id":"studio.samples.running-stats","version":"1.0.0","title":"Running Stats","requires":{"studio":"1.1","classes":["Object"]}}
!class RunningStats < Object | count total
!method instance
reset
  count := 0. total := 0.
  ^ total
!
!method instance
add: n
  total := total + n. count := count + 1.
  ^ total
!
!method instance
count
  ^ count
!
!method instance
total
  ^ total
!
!method instance
average
  count = 0 ifTrue: [ ^ 'No values yet' ].
  ^ total / count
!
!method class
start
  | app |
  app := self new. app reset.
  ^ app
!
!startup RunningStats start
