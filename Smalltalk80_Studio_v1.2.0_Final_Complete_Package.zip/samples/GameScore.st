!studio-package 1
!manifest {"id":"studio.examples.game-score","version":"1.0.0","title":"Game Score","requires":{"studio":"1.1","classes":[],"packages":[{"id":"studio.examples.guessing-game","version":"1.0.0"}]}}
!class GameScore < GuessingGame
!method instance
score
  ^ 100 - self attempts
!
!method class
start
  ^ self new initialize
!
!startup GameScore start
