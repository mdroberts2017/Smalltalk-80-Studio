# 1.2.0 Final implementation notes

Reference edition is the supplied NCITS J20 draft revision 1.9 (December 1997). The draft evidence is partial. Full draft coverage and conformance to the published ANSI edition remain unverified.

| Area | Final evidence |
| --- | --- |
| Studio, runtime and migration | 100 regression groups passed. All 29 inline scripts passed syntax checking. Native A6.3 and RC2 images carrying FloatD and staged binary data reopened and round-tripped alongside historical fixtures. |
| Draft probes | Nine passed, including a historic project save/reopen probe. Existing language-limit and Float format boundary tests reran on Final. |
| SIF | Studio executes original and reimported fixtures. A separate Python reader checked two exported files structurally. Behavioral interchange with another Smalltalk implementation remains open. |
| Offline startup | Static markup and CSS declare no external or local asset dependencies. Chromium failed at startup with `socket() failed: Operation not permitted`, before navigating to the HTML. Michael accepted RC2 in Safari, Firefox, Chrome, and Edge. Final browser launch was blocked in the local test environment. |

## Open deviations and implementation choices

- Draft §5.7 FileStream runs over a browser-managed file store. The Workspace stages local inputs and downloads output explicitly. Host path access, direct write-back, and operating-system access and permission semantics remain open. Text files use UTF-8. The draft file tests cover 4,096-byte transfer boundaries, binary access, and positioning at EOF. Generic stream `nextPutAll:` dispatch still needs broader coverage.
- Draft §5 global bindings are represented, with probes across core protocols. Selector-level behavior and error cases across object, block, exception, collection, time, and numeric protocols remain incompletely verified.
- Draft §§3.4.6.1 and 3.6 are covered by representative boundary tests. Unqualified decimal floating literals select binary32 when exactly representable and binary64 otherwise. Explicit E, D, and Q formats are recognized, with D and Q sharing IEEE binary64.
- Draft §§4.1 and following have structural and same-runtime SIF evidence. Additional constructs and independent Smalltalk execution remain open.

