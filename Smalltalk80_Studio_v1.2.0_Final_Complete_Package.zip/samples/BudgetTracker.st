!studio-package 1
!manifest {"id":"studio.examples.budget-tracker","version":"1.0.0","title":"Budget Tracker","requires":{"studio":"1.1","classes":["Object"]}}
!class BudgetTracker < Object | balance
!method instance
deposit: amount
  balance := balance + amount.
  ^ balance
!
!method instance
withdraw: amount
  amount > balance ifTrue: [ ^ 'Insufficient funds' ].
  balance := balance - amount.
  ^ balance
!
!method instance
balance
  ^ balance
!
!method instance
reset
  balance := 0.
  ^ self
!
!method class
start
  ^ self new reset
!
!startup BudgetTracker start
