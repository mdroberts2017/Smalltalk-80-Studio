"""Run with Python Playwright and a local Chromium installation."""
import copy
import json
import os
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

root = Path(__file__).resolve().parents[1]
html = next(root.glob('Smalltalk80_Studio_*_Final.html'))
guess = json.loads((root / 'samples/GuessingGame.st80pkg.json').read_text())
budget = json.loads((root / 'samples/BudgetTracker.st80pkg.json').read_text())
report = {}

with sync_playwright() as playwright:
    browser = playwright.chromium.launch(
        executable_path=os.environ.get('ST80_CHROMIUM', '/usr/bin/chromium'),
        args=['--no-sandbox', '--disable-dev-shm-usage'],
    )
    for width, height in [(1600, 900), (1280, 800)]:
        page = browser.new_page(viewport={'width': width, 'height': height}, accept_downloads=True)
        page.context.set_offline(True)
        external_requests = []
        page.on('request', lambda request: external_requests.append(request.url) if request.url.startswith(('http:', 'https:')) else None)
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.on('console', lambda message: errors.append(message.text) if message.type == 'error' else None)
        page.goto(html.as_uri())
        page.locator('#enterBtn').click()
        preflight = page.evaluate('ST80RC1Preflight.run()')
        assert preflight['passed'] == preflight['total'] == 12, preflight
        assert preflight['baseline']['passed'] == preflight['baseline']['total'] == 17
        page.evaluate('''() => {
            const h = ST80StudioVM12B.heap;
            h.setGlobal('P01Probe', 42);
            window.p01Fingerprint = () => JSON.stringify(Smalltalk80VMImage.save(h).heap);
            window.p01Original = p01Fingerprint();
            window.p01Heap = h;
        }''')
        lessons = page.locator('.nav [data-view="lessonView"]')
        assert lessons.evaluate("""button => {
            const b = button.getBoundingClientRect();
            const side = button.closest('.side').getBoundingClientRect();
            return b.top >= side.top && b.bottom <= Math.min(side.bottom, innerHeight);
        }""")
        lessons.click()
        expect(page.locator('#lessonView')).to_be_visible()
        page.locator('.nav [data-view="desktopView"]').click()
        page.locator('#workspaceText').fill("(#($A #(16rFF #'two words' #at:put:)) at: 2) at: 1")
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('255')
        page.locator('#workspaceText').fill('[:a :b :c | a + b + c] valueWithArguments: #(2 3 4)')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('9')
        page.locator('#workspaceText').fill('[1 / 0] on: ZeroDivide do: [:e | 7]')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('7')
        page.locator('#workspaceText').fill('0.10s2 + 0.2s')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('0.30s2')
        page.locator('#workspaceText').fill('(SortedCollection with: 7 with: 2 with: 1) first')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('1')
        page.evaluate('''() => {
            const h = new Smalltalk80IndependentVM.ImageHeap(), cc = new Smalltalk80SourceCompiler.MethodCompiler(h);
            cc.compile('Object', "a4bBrowser\n | f | f := FileStream write: 'browser-note'. f nextPutAll: 'café'. f close. ^ (FileStream read: 'browser-note') contents", {install: true});
            if (h.display(ST80UI15G.invoke(h,h.object,'a4bBrowser')) !== "'café'") throw Error('Named file reopen failed');
        }'''.replace('a4bBrowser\n','a4bBrowser\\n'))
        page.locator('#workspaceText').fill('7 perform: #+ with: 5')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('12')
        page.locator('#workspaceText').fill("Transcript show: ('A5 ' , 'browser probe'); cr")
        page.locator('#printItBtn').click()
        expect(page.locator('#transcript')).to_contain_text('A5 browser probe')
        page.locator('#workspaceText').fill('(ByteArray new: 65535) size')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('65535')
        page.locator('#workspaceText').fill('(1 / 8) hash = 0.125d0 hash')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill('(Duration seconds: 5) / (Duration seconds: 2)')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('5/2')
        page.locator('#workspaceText').fill('(ReadStream on: #(1 2)) peekFor: 1.0d0')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill('(1 / 8) printString')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('1/8')
        page.locator('#workspaceText').fill('(ReadStream on: #(42)) respondsTo: #peek')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill('(5 / 2) fractionPart')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('1/2')
        page.locator('#workspaceText').fill('FloatD respondsTo: #precision')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill("('a🍎z' at: 2) codePoint")
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('127822')
        page.locator('#workspaceText').fill('-255 printStringRadix: 16')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('-FF')
        page.locator('#workspaceText').fill("'review' asSymbol == #review")
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill('[42] respondsTo: #value')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill('0.0 sin')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('0.0')
        page.locator('#workspaceText').fill('FloatD respondsTo: #fmax')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('true')
        page.locator('#workspaceText').fill('0.1 class')
        page.locator('#printItBtn').click()
        expect(page.locator('#workspaceOutput')).to_contain_text('FloatD')
        page.locator('[data-modal="aboutModal"]').click()
        about = page.locator('#aboutModal')
        expect(about).to_contain_text('© 2026 Michael Roberts')
        expect(about).to_contain_text('GPL-3.0-or-later')
        assert about.locator('img.aboutLogo').evaluate('img => img.complete && img.naturalWidth === 512')
        about.locator('[data-close]').click()
        page.get_by_role('button', name='App Packages', exact=True).click()
        page.locator('#sifTools summary').click()
        page.locator('#sifFile').set_input_files(str(root / 'samples/SifLedger.sif'))
        expect(page.locator('#sifStatus')).to_contain_text('2 classes')
        page.locator('#sifExpression').fill('LedgerTotal')
        page.locator('#sifEvaluate').click()
        expect(page.locator('#sifOutput')).to_have_text('16')
        with page.expect_download() as sif_download:
            page.locator('#sifExport').click()
        assert sif_download.value.suggested_filename == 'SifLedger.sif'
        page.locator('#sifFile').set_input_files(str(root / 'samples/SifIndexed.sif'))
        expect(page.locator('#sifStatus')).to_contain_text('4 classes')
        page.locator('#sifExpression').fill('(IndexedOctetsChild basicNew: 4) lastByte: 255')
        page.locator('#sifEvaluate').click()
        expect(page.locator('#sifOutput')).to_have_text('255')

        page.locator('#sifTools summary').click()
        page.locator('#pkgRunSample').click()
        expect(page.locator('#pkgStatus')).to_have_text('Application started.')

        def send(selector, expected, args=None):
            page.locator('#pkgMethod').select_option(label=selector)
            if args is not None:
                page.locator('#pkgArgs').fill(args)
            page.locator('#pkgSendBtn').click()
            expect(page.locator('#pkgOutput')).to_contain_text(expected)

        for value, result in [(5, 'Higher'), (9, 'Lower'), (7, 'Correct!')]:
            send('guess:', result, str(value))
        send('attempts', 'attempts → 3')
        page.locator('#pkgFile').set_input_files({
            'name': 'bad.st80pkg.json', 'mimeType': 'application/json', 'buffer': b'{bad',
        })
        expect(page.locator('#pkgStatus')).not_to_have_text('Message completed.')
        send('attempts', 'attempts → 3')
        send('restart', 'restart →')
        send('attempts', 'attempts → 0')
        page.locator('#pkgFile').set_input_files(str(root / 'samples/BudgetTracker.st80pkg.json'))
        expect(page.locator('#pkgIdentity')).to_contain_text('Budget Tracker')
        send('deposit:', 'deposit: 120 → 120', '120')
        send('withdraw:', 'withdraw: 45 → 75', '45')
        send('balance', 'balance → 75')
        send('withdraw:', 'Insufficient funds', '999')
        send('balance', 'balance → 75')
        page.locator('#pkgMethod').select_option(label='withdraw:')
        page.locator('#pkgArgs').fill('1.5')
        page.locator('#pkgSendBtn').click()
        expect(page.locator('#pkgStatus')).to_have_text('Enter comma-separated integers.')
        for sample, title, method, arg, expected in [
            ('GuessingGame', 'Guessing Game', 'guess:', '7', 'Correct!'),
            ('BudgetTracker', 'Budget Tracker', 'deposit:', '120', 'deposit: 120 → 120'),
        ]:
            page.locator('#pkgSample').select_option(sample)
            page.locator('#pkgRunSample').click()
            with page.expect_download() as download:
                page.locator('#pkgExportSource').click()
            file = download.value
            data = Path(file.path()).read_bytes()
            assert file.suggested_filename.endswith('.st')
            assert data == (root / 'samples' / (sample + '.st')).read_bytes()
            page.locator('#pkgFile').set_input_files({
                'name': file.suggested_filename, 'mimeType': 'text/plain', 'buffer': data,
            })
            expect(page.locator('#pkgStatus')).to_have_text('Application started.')
            expect(page.locator('#pkgIdentity')).to_contain_text(title)
            send(method, expected, arg)

        page.locator('#pkgFile').set_input_files({
            'name': 'broken.st', 'mimeType': 'text/plain', 'buffer': b'unsupported',
        })
        expect(page.locator('#pkgStatus')).to_contain_text('broken.st:1:1')
        send('balance', 'balance → 120')
        page.locator('#pkgSample').select_option('GuessingGame')
        page.locator('#pkgInstallSample').click()
        expect(page.locator('#pkgStatus')).to_have_text('Installed Guessing Game.')
        with page.expect_file_chooser() as chooser:
            page.locator('#pkgInstallFile').click()
        chooser.value.set_files(str(root / 'samples/GameScore.st'))
        expect(page.locator('#pkgDetails')).to_contain_text('Requires: studio.examples.guessing-game 1.0.0')
        page.locator('#launcherApp').select_option('studio.examples.game-score')
        page.locator('#launchApp').click()
        send('score', 'score → 100')
        send('guess:', 'Correct!', '7')
        send('score', 'score → 99')
        page.locator('#appInspect').click()
        expect(page.locator('#pkgOutput')).to_contain_text('tries = 1')
        page.locator('#pkgMethod').select_option(label='guess:')
        page.locator('#appSource').click()
        expect(page.locator('#pkgOutput')).to_contain_text('GuessingGame >> guess:')
        page.locator('#appTrace').click()
        expect(page.locator('#pkgOutput')).to_contain_text('bytecodes')
        page.locator('#appOutput').click()
        original_project = page.locator('#projectList').input_value()
        page.locator('#projectName').fill('Budget Lab')
        page.locator('#projectNew').click()
        expect(page.locator('#pkgDetails')).to_have_text('No packages installed.')
        page.locator('#pkgSample').select_option('BudgetTracker')
        page.locator('#pkgInstallSample').click()
        with page.expect_download() as project_download:
            page.locator('#projectSave').click()
        project_file = project_download.value
        assert project_file.suggested_filename == 'Budget-Lab.st80project.json'
        project_bytes = Path(project_file.path()).read_bytes()
        page.locator('#projectList').select_option(original_project)
        expect(page.locator('#pkgIdentity')).to_contain_text('Game Score')
        page.locator('#pkgOutput').evaluate("(node) => { node.textContent = ''; }")
        send('score', 'score → 99')
        page.locator('#projectFile').set_input_files({
            'name': 'bad.st80project.json', 'mimeType': 'application/json', 'buffer': b'{bad',
        })
        expect(page.locator('#pkgStatus')).to_contain_text('bad.st80project.json:')
        expect(page.locator('#pkgIdentity')).to_contain_text('Game Score')
        page.locator('#projectFile').set_input_files({
            'name': project_file.suggested_filename, 'mimeType': 'application/json', 'buffer': project_bytes,
        })
        expect(page.locator('#pkgDetails')).to_contain_text('BudgetTracker')
        page.locator('#projectList').select_option(original_project)
        expect(page.locator('#pkgIdentity')).to_contain_text('Game Score')
        page.locator('#pkgInstalled').select_option('studio.examples.guessing-game')
        page.locator('#pkgRemove').click()
        expect(page.locator('#pkgStatus')).to_contain_text('Remove dependent package')
        send('score', 'score → 99')
        page.locator('#pkgInstalled').select_option('studio.examples.game-score')
        page.locator('#pkgRemove').click()
        expect(page.locator('#pkgStatus')).to_have_text('Removed Game Score.')
        expect(page.locator('#pkgSendBtn')).to_be_disabled()
        page.locator('#pkgRemove').click()
        expect(page.locator('#pkgDetails')).to_have_text('No packages installed.')
        bounds = page.evaluate('''() => {
            const panel = document.querySelector('#packageView');
            const view = panel.getBoundingClientRect();
            return ['projectList','projectNew','projectOpen','projectSave','projectSnapshot','projectRecover','launcherApp','launchApp','appInspect','appSource','appTrace','pkgRunSample','pkgOpen','pkgExportSource','pkgInstallSample','pkgInstallFile','pkgInstalled','pkgRunInstalled','pkgRemove','pkgSendBtn','pkgOutput'].map(id => {
                const b = document.getElementById(id).getBoundingClientRect();
                return b.left >= view.left && b.right <= view.right && b.top >= view.top - 1 && b.bottom <= view.bottom + 1;
            });
        }''')
        assert all(bounds)
        nav = page.locator('[data-view="packageView"]').bounding_box()
        assert nav['y'] + nav['height'] <= height
        assert page.evaluate('p01Heap === ST80StudioVM12B.heap && p01Original === p01Fingerprint()')
        assert page.evaluate('''data => {
            const a = ST80PackageP01.open(data), b = ST80PackageP01.open(data);
            a.send('guess:', [7]);
            return a.send('attempts', []) === '1' && b.send('attempts', []) === '0';
        }''', guess)
        cases = []
        def invalid(name, mutate, expected):
            candidate = copy.deepcopy(guess)
            mutate(candidate)
            error = page.evaluate('''data => {
                try { ST80PackageP01.open(data); return null; }
                catch (e) { return e.message; }
            }''', candidate)
            assert error and expected in error, (name, error)
            cases.append(name)

        invalid('schema', lambda p: p.update(schema=2), 'schema')
        invalid('kernel requirement', lambda p: p['requires']['classes'].append('Unresolved'), 'unavailable')
        invalid('kernel class collision', lambda p: p['classes'][0].update(name='Object') or p['startup'].update(className='Object'), 'collides')
        invalid('cyclic inheritance', lambda p: p['classes'][0].update(superclass='GuessingGame'), 'Cyclic')
        invalid('duplicate selector', lambda p: p['classes'][0]['methods'].append(p['classes'][0]['methods'][0]), 'Duplicate selector')
        invalid('compile error', lambda p: p['classes'][0]['methods'][0].update(source='broken\n ^ NoSuchGlobal'), 'Unknown variable')
        invalid('missing startup', lambda p: p['startup'].update(selector='missing'), 'defined directly')
        invalid('startup result', lambda p: p['classes'][0]['methods'][-1].update(source='start\n ^ 1'), 'must return')
        invalid('runtime failure', lambda p: p['classes'][0]['methods'][-1].update(source='start\n ^ self missingMessage'), 'missingMessage')

        # Forward declaration and inherited package methods use the same heap.
        derived = copy.deepcopy(guess)
        derived['classes'].insert(0, {'name': 'DerivedGame', 'superclass': 'GuessingGame', 'slots': [],
                                     'methods': [{'side': 'class', 'source': 'start\n ^ self new initialize'}]})
        derived['startup']['className'] = 'DerivedGame'
        assert page.evaluate('p => ST80PackageP01.open(p).send("attempts", [])', derived) == '0'
        invalid('inherited slot collision', lambda p: p['classes'].append(
            {'name': 'DerivedGame', 'superclass': 'GuessingGame', 'slots': ['secret'], 'methods': []}),
            'Inherited slot')

        page.locator('#projectSamples').click()
        page.locator('#launcherApp').select_option('studio.samples.pixel-pad')
        page.locator('#launchApp').click()
        canvas = page.locator('#appCanvas')
        expect(canvas).to_be_visible()
        canvas.click(position={'x': 4, 'y': 4})
        expect(page.locator('#appPixelStatus')).to_have_text('Pixel 0, 0 · Ink')
        canvas.press('ArrowRight')
        canvas.press('Enter')
        expect(page.locator('#appPixelStatus')).to_have_text('Pixel 1, 0 · Ink')
        with page.expect_download() as snapshot:
            page.locator('#projectSnapshot').click()
        file = snapshot.value
        assert file.suggested_filename == 'Sample-Apps-Live.st80project.json'
        page.locator('#projectFile').set_input_files({
            'name': file.suggested_filename, 'mimeType': 'application/json',
            'buffer': Path(file.path()).read_bytes(),
        })
        expect(page.locator('#appPixelStatus')).to_have_text('Pixel 1, 0 · Ink')
        page.locator('#appOutput').click()
        send('inkCount', 'inkCount → 2')
        page.locator('#launcherApp').select_option('studio.samples.running-stats')
        page.locator('#launchApp').click()
        send('add:', 'add: 2 → 2', '2')
        send('add:', 'add: 3 → 5', '3')
        send('average', 'average → 5/2')
        page.locator('#launcherApp').select_option('studio.samples.take-away')
        page.locator('#launchApp').click()
        send('take:', 'take: 1 → 11', '1')
        page.locator('[data-view="imageView"]').click()
        saved = {}
        for key, button in [('vm', '#saveVmImageBtn'), ('session', '#saveSessionBtn')]:
            with page.expect_download() as event:
                page.locator(button).click()
            saved[key] = Path(event.value.path()).read_bytes()
            assert json.loads(saved[key])['studioVersion'] == '1.2.0'
        page.locator('#openSessionInput').set_input_files({
            'name': 'session.json', 'mimeType': 'application/json', 'buffer': saved['session'],
        })
        expect(page.locator('#archiveLog')).to_contain_text('restored', ignore_case=True)
        page.locator('#vmImageInput').set_input_files({
            'name': 'bad.json', 'mimeType': 'application/json', 'buffer': b'{invalid',
        })
        expect(page.locator('#archiveLog')).to_contain_text('failed', ignore_case=True)
        for name, probe, initial in [('GuessingGame', 'Game', 'GuessingGame'), ('BudgetTracker', 'Budget', 'BudgetTracker')]:
            image = root / 'samples' / (name + '.st80image.json')
            page.locator('#vmImageInput').set_input_files(str(image))
            expect(page.locator('#archiveLog')).to_contain_text('restored', ignore_case=True)
            assert page.evaluate('''([probe, cls]) => {
                const h = ST80StudioVM12B.heap;
                return h.classOf(h.readAssociation(h.associations.get(probe))) === cls;
            }''', [probe, initial])
        assert not errors, errors
        report[f'{width}x{height}'] = {
            'browser': browser.version, 'release_integrity': preflight['passed'],
            'inherited_qualification': preflight['baseline']['passed'],
            'vm_and_compiler_regression': preflight['baseline']['tests'][:2],
            'package_ui_examples': ['Guessing Game', 'Budget Tracker'],
            'invalid_package_checks': cases, 'active_heap_unchanged': True,
            'sample_apps_pointer_and_keyboard': True, 'launcher_and_project_tools': True, 'named_project_round_trip_and_switch': True, 'project_install_run_and_remove': True, 'source_download_and_import': True, 'isolated_instances': True, 'forward_inheritance': True,
            'controls_within_stage': True, 'session_restored': True, 'corrupt_image_rejected': True,
            'version_1_0_example_images_restored': True, 'runtime_errors': errors,
        }
        page.locator('[data-view="packageView"]').click()
        page.locator('#externalFileTools summary').click()
        page.locator('#externalFileInput').set_input_files({
            'name': 'probe.bin', 'mimeType': 'application/octet-stream', 'buffer': b'\x00\xff\x0a'
        })
        expect(page.locator('#externalFileStatus')).to_contain_text('Imported probe.bin')
        with page.expect_download() as transfer:
            page.locator('#externalFileDownload').click()
        assert transfer.value.suggested_filename == 'probe.bin'
        assert Path(transfer.value.path()).read_bytes() == b'\x00\xff\x0a'
        page.locator('#externalFileTools summary').click()
        assert external_requests == [], external_requests
        page.close()
    browser.close()
(root / 'reports' / 'Final_Offline_Chromium.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
