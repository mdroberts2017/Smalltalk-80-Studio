# Smalltalk-80 Studio 1.2.0 Final · November 16, 2026

Version 1.2.0 promotes RC2, which Michael accepted in Safari, Firefox, Chrome, and Edge. The standalone uses the accepted runtime, with release labels, export metadata, and integrity-panel text updated for Final.

The 1.2 series expands Smalltalk syntax and literal support, numeric formats, exception and collection protocols, stream behavior, and SIF source interchange. The Workspace can import files into a browser-managed store for FileStream and export the resulting bytes. The illustrated offline guide includes steps for both SIF and FileStream.

Qualification used the supplied NCITS J20 draft revision 1.9. The software supports a tested subset of draft requirements, with open deviations and coverage limits documented in the implementation notes. Full ANSI conformance remains unverified.

Final automated checks cover execution, migration, and structural interchange. These include restoring an RC2 native image with FloatD and staged binary data, saving it under the Final version, and reopening it. Browser acceptance applies to RC2. A fresh Final browser launch was blocked in the test environment before navigation.
