/* Run with Node.js. Load the shipped runtime modules directly from the HTML. */
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.join(__dirname, '..');
const htmlName = fs.readdirSync(root).find(name => name.endsWith('_Final.html'));
const html = fs.readFileSync(path.join(root, htmlName), 'utf8');
const modules = [...html.matchAll(/<script>([\s\S]*?)<\/script>/g)].map(match => match[1]);
const context = vm.createContext({console, TextEncoder});
context.window = context;
const core = [
  'class ImageHeap', 'class MethodCompiler', "const FORMAT='smalltalk80-studio-vm-image'",
  'function ensureGraphics', 'g.Smalltalk80Numeric=', 'const evaluate=(heap,block',
  'class ProcessScheduler', 'Phase 15D kernel requires', 'Smalltalk80Kernel15E=',
  'g.ST80Form15F=API', 'g.ST80UI15G=API', 'g.ST80PackageP01 =', 'g.ST80PackageSource =', 'g.ST80Projects =', 'g.ST80ReleaseQualification =', 'g.ST80SIF=', 'g.ST80A4b=', 'g.ST80A5=',
];
const loaded = new Set();
for (const [index, source] of modules.entries()) {
  // Compile every inline script for syntax, including UI scripts not run by Node.
  const script = new vm.Script(source, {filename: htmlName + ':script-' + (index + 1)});
  // Some script tags contain multiple IIFEs, mixing runtime and DOM wiring.
  const bodies = source.match(/^\(function[^]*?^ ?}\)\([^\n]*\);/gm) || [];
  for (const body of bodies) {
    const keys = core.filter(marker => body.includes(marker));
    if (!keys.length) continue;
    for (const key of keys) loaded.add(key);
    new vm.Script(body).runInContext(context);
  }
}
assert.deepEqual([...loaded].sort(), [...core].sort());

const {Smalltalk80IndependentVM: VM, Smalltalk80SourceCompiler: CC, Smalltalk80VMImage: IO,
  ST80PackageP01: Packages, ST80UI15G: UI} = context;
if (process.argv.includes('--qualification')) {
  const trials = [
    ['numeric-decomposition', "((-2.25s2 integerPart) + (-2.25s2 fractionPart)) = -2.25s2", 'true'],
    ['radix-output', "-255 printStringRadix: 16", "'-FF'"],
    ['unicode-indexing', "('a🍎z' at: 2) codePoint", '127822'],
    ['stream-reflection', '(ReadStream on: #(42)) respondsTo: #peek', 'true'],
    ['computed-boolean-send', 'true perform: #ifTrue: with: [42]', '42'],
    ['boolean-reflection', 'true respondsTo: #ifTrue:', 'true'],
    ['block-reflection', '[42] respondsTo: #value', 'true'],
    ['string-as-symbol', "'qualification' asSymbol", '#qualification'],
  ];

  const observations = trials.map(([name, expression, expected]) => {
    const heap = new VM.ImageHeap();
    const cc = new CC.MethodCompiler(heap);
    let actual = '';
    let error = null;
    try {
      cc.compile('Object', 'qualificationProbe\n ^ ' + expression, {install: true});
      actual = heap.display(UI.invoke(heap, heap.object, 'qualificationProbe'));
    } catch (failure) {
      error = failure.message;
    }
    return {name, expression, expected, actual, error, result: actual === expected ? 'pass' : 'gap'};
  });

  const symbolHeap = new VM.ImageHeap();
  const symbolCompiler = new CC.MethodCompiler(symbolHeap);
  for (const selector of ['qualificationSymbolOne', 'qualificationSymbolTwo']) {
    symbolCompiler.compile('Object', selector + '\n ^ #qualification', {install: true});
  }
  const sameSymbol = UI.invoke(symbolHeap, symbolHeap.object, 'qualificationSymbolOne')
    === UI.invoke(symbolHeap, symbolHeap.object, 'qualificationSymbolTwo');
  observations.push({name: 'symbol-identity', expression: 'Compare the #qualification symbol returned by two compiled methods',
    expected: 'true', actual: String(sameSymbol), error: null, result: sameSymbol ? 'pass' : 'gap'});

  const previous = fs.readFileSync(path.join(root, 'samples', 'Legacy_A5_4_Project.st80project.json'), 'utf8');
  const io = context.ST80Projects;
  const opened = io.load(previous, 'A5.4 project');
  const before = opened.run.app.send('average', []);
  const saved = io.save(opened, true, opened.run);
  const savedVersion = JSON.parse(saved.text).image.studioVersion;
  const after = io.load(saved.text, 'A5.9 qualification resave').run.app.send('average', []);
  assert.equal(before, '5/2');
  assert.equal(after, before);
  assert.equal(savedVersion, '1.2.0');

  const report = {milestone: 'Final', executableVersion: savedVersion, results: observations,
    migration: {source: 'Legacy_A5_4_Project.st80project.json', before, after, result: 'pass'}};
  fs.writeFileSync(path.join(root, 'reports', 'Final_Protocol_Probes.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
  process.exit(0);
}

if (process.argv.includes('--ansi-probe')) {
  const examples = [
    ['precedence', '2 + 3 * 4'],
    ['explicit non-local return', 'true ifTrue: [ ^ 7 ]. ^ 9', true],
    ['dyadic block', '[:a :b | a + b] value: 2 value: 3'],
    ['three-argument block', '[:a :b :c | a + b + c] value: 1 value: 2 value: 3'],
    ['valuable protocol', '[:a | a + 1] valueWithArguments: #(2)'],
    ['radix integer', '16rFF'],
    ['scaled decimal', '1.25s2'],
    ['double exponent', '1.0d2'],
    ['character literal', '$A'],
    ['literal array', '#(1 2 3)'],
    ['hashed string', "#'red green'"],
    ['multi-keyword quoted selector', '#at:put:'],
    ['exact rational', '5 / 2'],
    ['fraction factory', 'Fraction numerator: 5 denominator: 2'],
    ['exception handler', '[1 / 0] on: Error do: [:e | 7]'],
    ['termination block', '[2] ensure: [3]'],
    ['missing message', 'self missingMessage'],
    ['array', '(Array new: 2) at: 1'],
    ['dictionary', 'Dictionary new at: #red put: 17'],
    ['set', 'Set new add: 1; add: 1; size'],
    ['read stream', '(ReadStream on: StudioNumbers) next'],
    ['date and time', 'DateAndTime now'],
    ['duration', 'Duration seconds: 1'],
    ['file stream global', 'FileStream'],
  ];
  const results = examples.map(([probe, source, complete]) => {
    const heap = new VM.ImageHeap();
    const compiler = new CC.MethodCompiler(heap);
    let method;
    try { method = compiler.compile('Object', 'probe\n' + (complete ? source : '^ ' + source), {install: true}); }
    catch (error) { return {probe, source, stage: 'compile', result: error.message}; }
    try { return {probe, source, stage: 'execution', result: heap.display(UI.invoke(heap, heap.object, method.selector))}; }
    catch (error) { return {probe, source, stage: 'runtime error', result: error.message}; }
  });
  console.log(JSON.stringify(results, null, 2));
  process.exit(0);
}
const fixtures = JSON.parse(html.match(/id="packageSamples">([^<]+)<\/script>/)[1]);
const results = [];

function check(name, test) {
  results.push({name, detail: test() ?? null});
}
function fixture(name, extension = 'st80pkg') {
  return JSON.parse(fs.readFileSync(path.join(root, 'samples', name + '.' + extension + '.json')));
}
function rejected(name, change, reason) {
  check(name, () => {
    const manifest = fixture('GuessingGame');
    change(manifest);
    assert.throws(() => Packages.open(manifest), reason);
  });
}

for (const [name, suite] of [['VM', VM], ['Compiler', CC]]) {
  check(name + ' regression', () => {
    const report = suite.selfTest();
    assert.equal(report.passed, report.total, JSON.stringify(report.results.filter(test => !test.ok)));
    return report.passed + '/' + report.total;
  });
}
for (const name of ['GuessingGame', 'BudgetTracker']) {
  check(name + ' embedded package matches file', () => assert.deepEqual(fixtures[name], fixture(name)));
}
const live = new VM.ImageHeap();
live.setGlobal('P01Probe', 42);
const fingerprint = () => JSON.stringify(IO.save(live).heap);
const before = fingerprint();

check('Guessing Game', () => {
  const game = Packages.open(fixtures.GuessingGame);
  for (const [guess, result] of [[5, 'Higher'], [9, 'Lower'], [7, 'Correct!']]) {
    assert.match(game.send('guess:', [guess]), new RegExp(result.replace('!', '\\!')));
  }
  assert.equal(game.send('attempts', []), '3');
  game.send('restart', []);
  assert.equal(game.send('attempts', []), '0');
});
check('Budget Tracker', () => {
  const budget = Packages.open(fixtures.BudgetTracker);
  assert.equal(budget.send('deposit:', [120]), '120');
  assert.equal(budget.send('withdraw:', [45]), '75');
  assert.match(budget.send('withdraw:', [999]), /Insufficient funds/);
  assert.equal(budget.send('balance', []), '75');
  budget.send('reset', []);
  assert.equal(budget.send('balance', []), '0');
});
check('Independent package instances and failed send validation', () => {
  const first = Packages.open(fixtures.GuessingGame);
  const second = Packages.open(fixtures.GuessingGame);
  first.send('guess:', [7]);
  assert.throws(() => first.send('guess:', [0.5]), /integer/);
  assert.throws(() => first.send('guess:', []), /integer/);
  assert.throws(() => first.send('doesNotExist', []), /Select a package/);
  assert.equal(first.send('attempts', []), '1');
  assert.equal(second.send('attempts', []), '0');
});
check('Forward inheritance, class-side startup and inherited selector', () => {
  const packageFile = fixture('GuessingGame');
  packageFile.classes.unshift({
    name: 'DerivedGame', superclass: 'GuessingGame', slots: [],
    methods: [{side: 'class', source: 'start\n ^ self new initialize'}],
  });
  packageFile.startup.className = 'DerivedGame';
  assert.equal(Packages.open(packageFile).send('attempts', []), '0');
});
rejected('Incompatible schema', p => { p.schema = 2; }, /schema/);
rejected('Missing kernel requirement', p => p.requires.classes.push('UnavailableClass'), /unavailable/);
rejected('Kernel class collision', p => { p.classes[0].name = p.startup.className = 'Object'; }, /collides/);
rejected('Missing superclass declaration', p => { p.requires.classes = []; }, /declared kernel/);
rejected('Cyclic inheritance', p => { p.classes[0].superclass = 'GuessingGame'; }, /Cyclic/);
rejected('Inherited slot collision', p => p.classes.push({
  name: 'DerivedGame', superclass: 'GuessingGame', slots: ['secret'], methods: [],
}), /Inherited slot/);
rejected('Duplicate selector', p => p.classes[0].methods.push(p.classes[0].methods[0]), /Duplicate selector/);
rejected('Compiler failure', p => { p.classes[0].methods[0].source = 'bad\n ^ MissingGlobal'; }, /Unknown variable/);
rejected('Missing startup', p => { p.startup.selector = 'missing'; }, /defined directly/);
rejected('Invalid startup result', p => { p.classes[0].methods.at(-1).source = 'start\n ^ 1'; }, /must return/);
rejected('Startup runtime error', p => { p.classes[0].methods.at(-1).source = 'start\n ^ self missingMessage'; }, /missingMessage/);
check('Studio heap remains unchanged after package success and failure', () => assert.equal(fingerprint(), before));

check('Studio image round-trip and malformed image rejection', () => {
  const image = JSON.parse(JSON.stringify(IO.save(live)));
  assert.equal(image.studioVersion, '1.2.0');
  const restored = IO.restore(image).heap;
  assert.equal(restored.readAssociation(restored.associations.get('P01Probe')), 42);
  image.heap.roots.object = 'bad';
  assert.throws(() => IO.restore(image), /Invalid VM image/);
});
for (const [name, binding, selector, args, expected] of [
  ['GuessingGame', 'Game', 'guess:', [7], /Correct/],
  ['BudgetTracker', 'Budget', 'deposit:', [120], /120/],
]) {
  check('1.0 VM image restore and execution: ' + name, () => {
    const {heap} = IO.restore(fixture(name, 'st80image'));
    const receiver = heap.readAssociation(heap.associations.get(binding));
    assert.match(heap.display(UI.invoke(heap, receiver, selector, args)), expected);
  });
}

const sourceIO = context.ST80PackageSource;
for (const [name, actions] of [
  ['GuessingGame', [['attempts', [], '0'], ['guess:', [5], "'Higher'"],
    ['guess:', [9], "'Lower'"], ['guess:', [7], "'Correct!'"], ['attempts', [], '3']]],
  ['BudgetTracker', [['balance', [], '0'], ['deposit:', [120], '120'],
    ['withdraw:', [45], '75'], ['withdraw:', [999], "'Insufficient funds'"], ['balance', [], '75']]],
]) {
  check(name + ' source round-trip: metadata, class layout, methods, startup and behavior', () => {
    const original = fixtures[name];
    const text = sourceIO.fileOut(original);
    const sample = path.join(root, 'samples', name + '.st');
    if (process.argv.includes('--write-samples')) fs.writeFileSync(sample, text);
    assert.equal(fs.readFileSync(sample, 'utf8'), text);
    const {manifest, app} = sourceIO.open('\uFEFF' + text.replace(/\n/g, '\r\n'), name + '.st');
    assert.deepEqual(JSON.parse(JSON.stringify(manifest)), original);
    assert.equal(sourceIO.fileOut(manifest), text);
    const originalApp = Packages.open(original);
    for (const [selector, args, expected] of actions) {
      const originalResult = originalApp.send(selector, args);
      assert.equal(app.send(selector, args), originalResult);
      assert.equal(originalResult.replace(/^"|"$/g, "'"), expected);
    }
  });
}
check('File-out preserves delimiters, backslashes, Unicode and source line endings', () => {
  const manifest = fixture('BudgetTracker');
  const method = {side: 'instance', source: 'notes\r\n "multi-line\n!\n\\!\n\\=\n–é\n"\n ^ 42\n'};
  manifest.classes[0].methods.push(method);
  const text = sourceIO.fileOut(manifest);
  const loaded = sourceIO.open(text, 'escapes.st');
  assert.equal(loaded.manifest.classes[0].methods.at(-1).source, method.source);
  assert.equal(loaded.app.send('notes', []), '42');
});
check('File-in reports framing and compiler locations', () => {
  const text = sourceIO.fileOut(fixtures.GuessingGame);
  assert.throws(() => sourceIO.open('legacyListing', 'legacy.st'), /legacy\.st:1:1: Expected !studio-package 1/);
  assert.throws(() => sourceIO.open('!studio-package 1\n!manifest {', 'bad.st'), /bad\.st:2:1: Invalid JSON/);
  assert.throws(() => sourceIO.open(text.slice(0, text.indexOf('\n!', text.indexOf('!method') + 1)), 'short.st'),
    /short\.st:4:1: Unterminated method/);
  const invalid = text.replace('  secret := 7.', '  secret := ).');
  const line = invalid.split('\n').findIndex(line => line.includes('secret := )')) + 1;
  assert.throws(() => sourceIO.open(invalid, 'compiler.st'),
    new RegExp('compiler\\.st:' + line + ':13: GuessingGame'));
  const missing = text.replace('secret := 7', 'secret := MissingGlobal');
  assert.throws(() => sourceIO.open(missing, 'binding.st'), /binding\.st:5:1: GuessingGame.*Unknown variable/);
  assert.throws(() => sourceIO.open(text + '!extra', 'trailing.st'), /Unexpected content after !startup/);
  assert.equal(fingerprint(), before);
});

check('Project dependencies, rollback and removal', () => {
  const project = Packages.createProject();
  const dependency = fixture('GuessingGame');
  const extension = fixture('GameScore');
  const baseId = dependency.id;
  const extensionId = extension.id;
  assert.throws(() => project.install(extension), /Install it first/);
  assert.equal(project.list().length, 0);
  project.install(dependency);
  const active = project.run(baseId);
  active.send('guess:', [7]);
  const badVersion = fixture('GameScore');
  badVersion.requires.packages[0].version = '2.0.0';
  assert.throws(() => project.install(badVersion), /requires .* 2.0.0, installed 1.0.0/);
  assert.throws(() => project.install(dependency), /already installed/);
  const duplicateClass = fixture('GuessingGame');
  duplicateClass.id = 'studio.tests.duplicate';
  assert.throws(() => project.install(duplicateClass), /collides/);
  const undeclaredClass = fixture('BudgetTracker');
  undeclaredClass.classes[0].methods.push({side: 'instance', source: 'foreignClass\n ^ GuessingGame'});
  assert.throws(() => project.install(undeclaredClass), /undeclared package dependency/);
  const broken = fixture('GameScore');
  broken.classes[0].methods[0].source = 'score\n ^ UnknownGlobal';
  assert.throws(() => project.install(broken), /Unknown variable/);
  assert.equal(active.send('attempts', []), '1');
  assert.deepEqual(Array.from(project.list(), item => item.id), [baseId]);
  const installSource = sourceIO.fileOut(extension);
  const sample = path.join(root, 'samples', 'GameScore.st');
  if (process.argv.includes('--write-samples')) fs.writeFileSync(sample, installSource);
  assert.equal(fs.readFileSync(sample, 'utf8'), installSource);
  sourceIO.withSource(installSource, 'GameScore.st', manifest => project.install(manifest));
  assert.throws(() => active.send('attempts', []), /project changed/);
  assert.equal(project.inspect(extensionId).requires.packages[0].id, baseId);
  const copy = project.inspect(extensionId);
  copy.requires.packages.length = 0;
  const app = project.run(extensionId);
  assert.equal(app.send('score', []), '100');
  assert.match(app.send('guess:', [7]), /Correct/);
  assert.equal(app.send('score', []), '99');
  assert.throws(() => project.remove(baseId), /Remove dependent package/);
  assert.equal(app.send('score', []), '99');
  project.remove(extensionId);
  assert.equal(project.run(baseId).send('attempts', []), '0');
  project.remove(baseId);
  assert.equal(project.list().length, 0);
  assert.throws(() => project.run(extensionId), /Select an installed package/);
  assert.equal(fingerprint(), before);
});
check('Project packages execute against a shared VM', () => {
  const project = Packages.createProject();
  const dependency = fixture('GuessingGame');
  dependency.classes[0].methods.push({side: 'instance', source: 'sharedValue\n ^ StudioAnswer'});
  const extension = fixture('GameScore');
  extension.classes[0].methods.push({side: 'instance', source: 'updateShared\n StudioAnswer := 71. ^ StudioAnswer'});
  project.install(dependency);
  project.install(extension);
  const base = project.run(dependency.id);
  assert.equal(base.send('sharedValue', []), '42');
  assert.equal(project.run(extension.id).send('updateShared', []), '71');
  assert.equal(base.send('sharedValue', []), '71');
  assert.equal(fingerprint(), before);
});

check('Portable project round-trip and dependency validation', () => {
  const io = context.ST80Projects;
  const project = io.create('Game Lab');
  const base = fixture('GuessingGame');
  const extension = fixture('GameScore');
  project.vm.install(base);
  project.vm.install(extension);
  project.selected = extension.id;
  const app = project.vm.run(extension.id);
  app.send('guess:', [7]);
  const {filename, text} = io.save(project);
  assert.equal(filename, 'Game-Lab.st80project.json');
  const sample = path.join(root, 'samples', filename);
  if (process.argv.includes('--write-samples')) fs.writeFileSync(sample, text);
  assert.equal(fs.readFileSync(sample, 'utf8'), text);
  const restored = io.load('\uFEFF' + text, filename);
  assert.equal(restored.selected, extension.id);
  assert.equal(io.save(restored).text, text);
  assert.equal(restored.vm.run(extension.id).send('score', []), '100');
  const payload = JSON.parse(text);
  payload.packages.reverse();
  assert.equal(io.load(JSON.stringify(payload), filename).vm.run(extension.id).send('score', []), '100');
  payload.packages.pop();
  assert.throws(() => io.load(JSON.stringify(payload), 'missing.json'), /missing.json: .*requires/);
  assert.throws(() => io.load(text.replace('"schema": 1', '"schema": 9'), 'schema.json'), /schema.json: Expected/);
  payload.packages.push(extension);
  assert.throws(() => io.load(JSON.stringify(payload), 'duplicate.json'), /Duplicate package ID/);
  assert.equal(app.send('score', []), '99');
  assert.equal(fingerprint(), before);
});

check('Launcher instances, owning-VM tools and startup errors', () => {
  const first = Packages.createProject([fixture('GuessingGame'), fixture('GameScore')]);
  const second = Packages.createProject([fixture('GuessingGame'), fixture('GameScore')]);
  const id = fixture('GameScore').id;
  const app = first.run(id);
  const other = second.run(id);
  assert.match(app.inspect(), /tries = 0/);
  assert.match(app.source('guess:'), /^GuessingGame >> guess:/);
  app.send('guess:', [7]);
  assert.match(app.inspect(), /tries = 1/);
  assert.match(other.inspect(), /tries = 0/);
  assert.match(first.run(id).inspect(), /tries = 0/);
  assert.match(app.trace(), /GuessingGame>>guess:/);
  const broken = fixture('BudgetTracker');
  broken.classes[0].methods.at(-1).source = 'start\n ^ self missingMessage';
  first.install(broken);
  assert.throws(() => app.inspect(), /project changed/);
  assert.throws(() => app.source('guess:'), /project changed/);
  assert.throws(() => app.trace(), /project changed/);
  const active = first.run(id);
  active.send('guess:', [7]);
  assert.throws(() => first.run(broken.id), /Budget Tracker startup failed .*BudgetTracker class >> start.*missingMessage/);
  assert.match(active.inspect(), /tries = 1/);
  assert.equal(fingerprint(), before);
});

const sampleProject = fixture('Sample-Apps', 'st80project');
check('Sample Apps portable project and Smalltalk program behavior', () => {
  const embedded = html.match(/id="sampleAppsProject">([^<]+)<\/script>/)[1];
  assert.deepEqual(JSON.parse(embedded), sampleProject);
  const project = context.ST80Projects.load(embedded, 'Sample Apps');
  for (const manifest of sampleProject.packages) {
    const name = manifest.startup.className;
    assert.deepEqual(manifest, fixture(name));
    const text = sourceIO.fileOut(manifest);
    const sample = path.join(root, 'samples', name + '.st');
    if (process.argv.includes('--write-samples')) fs.writeFileSync(sample, text);
    assert.equal(fs.readFileSync(sample, 'utf8'), text);
    assert.equal(sourceIO.open(text, name + '.st').app.id, manifest.id);
  }
  const game = project.vm.run('studio.samples.take-away');
  assert.equal(game.send('take:', [4]), '15');
  for (const count of ['11', '7', '3']) assert.equal(game.send('take:', [1]), count);
  assert.equal(game.send('take:', [3]), '0');
  assert.equal(game.send('winner', []), '1');
  game.send('reset', []);
  for (let i = 0; i < 4; i++) game.send('take:', [1]);
  assert.equal(game.send('winner', []), '2');
  const utility = project.vm.run('studio.samples.running-stats');
  assert.match(utility.send('average', []), /No values yet/);
  utility.send('add:', [-2]);
  utility.send('add:', [5]);
  assert.equal(utility.send('average', []), '3/2');
  const pad = project.vm.run('studio.samples.pixel-pad');
  assert.equal(pad.hasDisplay, true);
  assert.equal(pad.acceptsPointer, true);
  const blank = pad.display();
  assert.equal(blank.width, 32);
  assert.equal(blank.height, 20);
  assert.equal(pad.send('pointerX:y:', [31, 19]), '1');
  assert.equal(pad.display().pixels.at(-1), 1);
  assert.equal(blank.pixels.at(-1), 0);
  assert.equal(pad.send('pointerX:y:', [32, 19]), '0');
  assert.equal(pad.send('inkCount', []), '1');
  assert.equal(pad.send('invert', []), '639');
  assert.equal(project.vm.run('studio.samples.pixel-pad').send('inkCount', []), '0');
  assert.equal(fingerprint(), before);
});

check('Live snapshots preserve receivers and recover from damaged or interrupted checkpoints', () => {
  const io = context.ST80Projects;
  const project = io.load(JSON.stringify(sampleProject), 'samples');
  const app = project.vm.run('studio.samples.pixel-pad');
  app.send('pointerX:y:', [31, 19]);
  const run = {app, lines: ['Pixel marked'], method: '2', args: '31, 19', toolMode: 'display', pixel: {x: 31, y: 19}};
  const first = io.save(project, true, run);
  assert.match(first.filename, /-Live\.st80project\.json$/);
  const restored = io.load(first.text, 'live');
  assert.equal(restored.run.app.display().pixels.at(-1), 1);
  assert.equal(restored.run.app.send('inkCount', []), '1');
  assert.equal(restored.run.args, '31, 19');
  assert.equal(restored.run.lines[0], 'Pixel marked');
  assert.equal(restored.vm.run('studio.samples.pixel-pad').send('inkCount', []), '0');
  for (const [id, selector, args, query, expected] of [
    ['studio.samples.take-away', 'take:', [1], 'remaining', '11'],
    ['studio.samples.running-stats', 'add:', [12], 'total', '12'],
  ]) {
    const other = project.vm.run(id);
    other.send(selector, args);
    const snapshot = io.save(project, true, {...run, app: other, method: '0', toolMode: 'output'});
    assert.equal(io.load(snapshot.text, 'live').run.app.send(query, []), expected);
  }
  const corrupt = JSON.parse(first.text);
  corrupt.image.heap.methods.find(method => method.className === 'PixelPad').bytes[0] ^= 1;
  assert.throws(() => project.vm.restore(corrupt.image), /methods do not match/);
  assert.equal(app.send('inkCount', []), '1');
  const data = new Map();
  let failWrite = false;
  const storage = {
    getItem: key => data.get(key),
    setItem(key, value) {
      if (failWrite && !key.endsWith('.previous')) throw Error('storage quota');
      data.set(key, value);
    },
  };
  io.checkpoint(storage, first.text);
  app.send('pointerX:y:', [0, 0]);
  const second = io.save(project, true, run).text;
  failWrite = true;
  assert.throws(() => io.checkpoint(storage, second), /storage quota/);
  assert.equal(io.recover(storage).project.run.app.send('inkCount', []), '1');
  failWrite = false;
  io.checkpoint(storage, second);
  assert.equal(io.recover(storage).project.run.app.send('inkCount', []), '2');
  const latest = [...data.keys()].find(key => !key.endsWith('.previous'));
  data.set(latest, '{broken');
  assert.equal(io.recover(storage).label, 'Previous checkpoint');
  assert.equal(io.recover(storage).project.run.app.send('inkCount', []), '1');
});

check('In-app release qualification passes with isolated projects', () => {
  const source = html.match(/id="sampleAppsProject">([^<]+)<\/script>/)[1];
  const checks = context.ST80ReleaseQualification.run(source);
  assert.equal(checks.length, 3);
  assert(checks.every(item => item.status === 'pass'), JSON.stringify(checks));
  assert.equal(fingerprint(), before);
  return checks.map(item => item.name);
});

check('A1a literal source, types, nested arrays and VM image round-trip', () => {
  const heap = new VM.ImageHeap();
  const compiler = new CC.MethodCompiler(heap);
  const evaluate = expression => {
    compiler.compile('Object', 'ansiLiteralProbe\n ^ ' + expression, {install: true});
    return UI.invoke(heap, heap.object, 'ansiLiteralProbe');
  };
  assert.equal(evaluate('16rFF'), 255);
  assert.equal(evaluate('-2r101'), -5);
  assert.equal(heap.display(evaluate('16r10000000000000000')), '18446744073709551616');
  assert.equal(heap.display(evaluate('$😀 asString')), "'😀'");
  assert.equal(heap.fetch(evaluate('#at:put:')).text, 'at:put:');
  assert.equal(heap.fetch(evaluate("#'can''t'")).text, "can't");
  const value = evaluate("#($A #(16rFF true nil false #'two words') () -2r101 1.5)");
  const [char, nested, empty, negative, float] = heap.fetch(value).indexed;
  assert.equal(heap.fetch(char).slots.codePoint, 65);
  const [radix, yes, nil, no, symbol] = heap.fetch(nested).indexed;
  assert.equal(radix, 255);
  assert.equal(yes, heap.true);
  assert.equal(nil, heap.nil);
  assert.equal(no, heap.false);
  assert.equal(heap.classOf(symbol), 'Symbol');
  assert.equal(heap.fetch(symbol).text, 'two words');
  assert.equal(heap.fetch(empty).indexed.length, 0);
  assert.equal(negative, -5);
  assert.equal(heap.classOf(float), 'Float');
  const reopened = IO.restore(JSON.parse(JSON.stringify(IO.save(heap)))).heap;
  assert.equal(UI.invoke(reopened, reopened.object, 'ansiLiteralProbe'), value);
  assert.equal(reopened.fetch(symbol).text, 'two words');
  assert.equal(reopened.fetch(char).slots.codePoint, 65);
});

check('A1a malformed input diagnostics identify the source location', () => {
  const heap = new VM.ImageHeap();
  const compiler = new CC.MethodCompiler(heap);
  for (const [expression, expected] of [
    ['$', /character.*line 2, column 4/],
    ['1r0', /radix must.*line 2, column 4/],
    ['2r102', /Invalid digit 2.*line 2, column 8/],
    ['16r', /Expected digits.*line 2, column 4/],
    ['#(1 #(2)', /Unterminated literal array.*line 2/],
    ['#(1 [2])', /Expected a literal.*line 2/],
    ["#'open", /Unterminated string.*line 2/],
  ]) {
    assert.throws(() => compiler.compile('Object', 'invalidLiteral\n ^ ' + expression, {install: true}), expected);
    assert.equal(heap.classes.get('Object').methods.has('invalidLiteral'), false);
  }
});

check('A1a package source and project snapshot round-trip', () => {
  const manifest = fixture('GuessingGame');
  manifest.classes[0].methods.push({
    side: 'instance',
    source: "ansiLiteralProbe\n ^ (#($Z #(16rFF #'two words' #at:put:)) at: 2) at: 1",
  });
  const source = sourceIO.fileOut(manifest);
  assert.equal(sourceIO.open(source, 'LiteralDemo.st').app.send('ansiLiteralProbe', []), '255');
  const io = context.ST80Projects;
  const project = io.create('Literal Demo');
  project.vm.install(manifest);
  const app = project.vm.run(manifest.id);
  const run = {app, lines: [], method: '0', args: '', toolMode: 'output', pixel: {x: 0, y: 0}};
  const reopened = io.load(io.save(project, true, run).text, 'Literal Demo');
  assert.equal(reopened.run.app.send('ansiLiteralProbe', []), '255');
});

check('A1b generalized closure arguments, sequence dispatch and control flow', () => {
  const heap = new VM.ImageHeap();
  const compiler = new CC.MethodCompiler(heap);
  const run = source => {
    compiler.compile('Object', 'wideProbe\n' + source, {install: true});
    return UI.invoke(heap, heap.object, 'wideProbe');
  };
  for (const n of [0, 1, 2, 3, 15, 31]) {
    const names = Array.from({length: n}, (_, i) => 'a' + (i + 1));
    const block = '[' + (n ? names.map(x => ':' + x).join(' ') + ' | ' : '') + (names.at(-1) || '0') + ']';
    const args = names.map((_, i) => i + 1);
    assert.equal(run(' ^ ' + block + ' argumentCount'), n);
    assert.equal(run(' ^ ' + block + (n ? args.map(x => ' value: ' + x).join('') : ' value')), n);
    assert.equal(run(' ^ ' + block + ' valueWithArguments: #(' + args.join(' ') + ')'), n);
  }
  assert.equal(run(' | seq | seq := OrderedCollection new. seq add: 4. seq add: 6. ^ [:a :b | a + b] valueWithArguments: seq'), 10);
  heap.defineClass('ArgumentSequence','Object',[]);
  compiler.compile('ArgumentSequence','size\n ^ 3',{install:true});
  compiler.compile('ArgumentSequence','at: i\n ^ i + 3',{install:true});
  assert.equal(run(' ^ [:a :b :c | a + b + c] valueWithArguments: ArgumentSequence new'), 15);
  assert.equal(run(' | x | x := 40. ^ ([:a :b :c | [:x | x + a + b + c]] value: 1 value: 2 value: 3) value: x'), 46);
  assert.equal(run(' [:a :b :c | ^ a + b + c] valueWithArguments: #(2 3 4). ^ 0'), 9);
  assert.throws(() => run(' ^ [:a :b :c | a] valueWithArguments: #(1 2)'), /Block expected 3/);
  assert.throws(() => run(' ^ [' + Array.from({length:32}, (_, i) => ':a'+i).join(' ') + ' | 0]'), /up to 31/);
});

check('A1b saved closure compatibility and image validation', () => {
  const heap = new VM.ImageHeap();
  const compiler = new CC.MethodCompiler(heap);
  const install = (source) => compiler.compile('Object', source, {install:true});
  for (const [selector, source] of [
    ['wideClosure', 'wideClosure\n | captured | captured := 10. ^ [:a :b :c | captured + a + b + c]'],
    ['oldClosure', 'oldClosure\n ^ [:a :b | a + b]'],
  ]) {
    install(source);
    heap.setGlobal(selector === 'wideClosure' ? 'WideClosure' : 'OldClosure', UI.invoke(heap,heap.object,selector));
  }
  install('probeRestored\n ^ (WideClosure valueWithArguments: #(1 2 3)) + (OldClosure value: 2 value: 3)');
  const image=JSON.parse(JSON.stringify(IO.save(heap)));
  const restored=IO.restore(image).heap;
  assert.equal(UI.invoke(restored,restored.object,'probeRestored'),21);
  image.heap.methods.find(m=>m.selector==='wideClosure').blocks[0].argCount=32;
  assert.throws(()=>IO.restore(image),/invalid block record/);
  const legacy=JSON.parse(fs.readFileSync(path.join(root,'samples','Legacy_A1a_Closure.st80image.json'),'utf8'));
  const legacyHeap=IO.restore(legacy).heap;
  assert.equal(UI.invoke(legacyHeap,legacyHeap.object,'probeLegacyClosure'),47);
});

check('A1b persists a 500-character keyword selector', () => {
  const heap=new VM.ImageHeap();
  const selector='long'+'x'.repeat(495)+':';
  new CC.MethodCompiler(heap).compile('Object',selector+' arg\n ^ arg',{install:true});
  const restored=IO.restore(JSON.parse(JSON.stringify(IO.save(heap)))).heap;
  assert.equal(UI.invoke(restored,restored.object,selector,[13]),13);
});

check('A2 failed-message dispatch, nested typed handlers and diagnostics', () => {
  const heap=new VM.ImageHeap(), cc=new CC.MethodCompiler(heap);
  const run=source=>{
    cc.compile('Object','a2Probe\n'+source,{install:true});
    return UI.invoke(heap,heap.object,'a2Probe');
  };
  heap.defineClass('MessageProxy','Object',[]);
  cc.compile('MessageProxy','doesNotUnderstand: m\n ^ (m arguments at: 1) + 10',{install:true});
  assert.equal(run(' ^ MessageProxy new absent: 5'),15);
  assert.equal(heap.display(run(" ^ [self absent] on: MessageNotUnderstood do: [:e | e message selector]")), '#absent');
  assert.equal(run(' ^ [[1 / 0] on: MessageNotUnderstood do: [:m | 6]] on: Error do: [:e | 7]'),7);
  assert.equal(run(' ^ [[Error signal] on: Error do: [:e | Error signal]] on: Error do: [:e | 11]'),11);
  assert.throws(()=>run(' ^ self missingMessage'),/Message not understood/);
});

check('A2 unwind order, return, resume and retry', () => {
  const heap=new VM.ImageHeap(), cc=new CC.MethodCompiler(heap);
  const run=source=>{
    cc.compile('Object','a2Transfer\n'+source,{install:true});
    return UI.invoke(heap,heap.object,'a2Transfer');
  };
  assert.equal(run(' | x | x := 0. [ [ [ Error signal ] ensure: [ x := 2 ] ] ifCurtailed: [ x := x + 3 ] ] on: Error do: [:e | e return: 8]. ^ x'),5);
  assert.equal(run(' ^ [ [ ^ 12 ] ensure: [ StudioAnswer := 18 ] ] value'),12);
  assert.equal(run(' ^ StudioAnswer'),18);
  assert.equal(run(' | x | x := 0. [ 2 ] ifCurtailed: [ x := 8 ]. ^ x'),0);
  assert.equal(run(' | x | x := 0. ^ [ (Notification signal) + 4 ] on: Notification do: [:e | [ e resume: 3 ] ensure: [ x := 1 ]]'),7);
  assert.equal(run(' ^ [ Error signal ] on: Error do: [:e | e retryUsing: [ 22 ]]'),22);
  assert.equal(run(' | x | x := 0. ^ [ x := x + 1. x = 1 ifTrue: [ Error signal ]. x ] on: Error do: [:e | e retry]'),2);
  assert.equal(run(' ^ [ #(1 2) do: [:n | n = 2 ifTrue: [ Error signal ]] ] on: Error do: [:e | 4]'),4);
  assert.throws(()=>run(" ^ [ Error signal: 'uncaught' ] ensure: [ StudioAnswer := 24 ]"),/uncaught/);
  assert.equal(run(' ^ StudioAnswer'),24);
  assert.equal(run(' ^ [1 / 0] on: ZeroDivide do: [:e | 5]'),5);
  assert.equal(run(' ^ [(1 / 0) + 3] on: ZeroDivide do: [:e | e resume: 5]'),8);
  assert.equal(run(' ^ [(self absent) + 3] on: MessageNotUnderstood do: [:e | e resume: 6]'),9);
});

check('A2 opens a live project snapshot produced by A1b', () => {
  const source=fs.readFileSync(path.join(root,'samples','Legacy_A1b_Project.st80project.json'),'utf8');
  const project=context.ST80Projects.load(source,'legacy A1b project');
  assert.equal(project.run.app.display().pixels[4*32+3],1);
  assert.equal(project.run.app.send('inkCount',[]),'1');
});
check('A3 SIF definitions, scoped bindings, initializer ordering and round-trip', () => {
  const {open}=context.ST80SIF;
  const source=fs.readFileSync(path.join(root,'samples','SifLedger.sif'),'utf8');
  const initial= open(source);
  assert.equal(initial.classCount,2);
  assert.equal(initial.evaluate('LedgerTotal'),'16');
  assert.equal(initial.evaluate('SifLedger total'),'15');
  assert.equal(initial.evaluate('SifChildLedger total'),'16');
  assert.equal(initial.evaluate('SifLedger new announce'),"'Ready!'");
  assert.equal(open(initial.export()).evaluate('LedgerTotal'),'16');
  assert.throws(()=>initial.evaluate('(LedgerBase := 20)'),/Cannot assign to constant/);
  assert.throws(()=>open(source.replace(' ^ Shared + local + Step',' Step := 1. ^ local')),/Cannot assign to constant Step/);
  assert.throws(()=>open(source.replace(' ^ Shared + local + Step',' ^ StudioSifBinding1')),/Unknown variable/);
  assert.throws(()=>open(source.replace("  indexedInstanceVariables: #'none'","  indexedInstanceVariables: #'byte'")),/Byte indexed classes cannot/);
  assert.throws(()=>open(source+'broken'),/terminator/);
  assert.throws(()=>open(source.replace(' LedgerTotal := SifChildLedger total',' 1 / 0')),/Division by zero/);
  assert.equal(initial.evaluate('LedgerTotal'),'16');
});

check('A3 initializer values and scope, empty definitions, and inheritance validation', () => {
  const {open}=context.ST80SIF;
  const source="Smalltalk interchangeVersion: '1.0'!\nGlobal constant: 'Probe'!\nProbe initializer!\n | x | x := 2. x + 5!";
  assert.equal(open(source).evaluate('Probe'),'7');
  assert.equal(open(source.replace(' | x | x := 2. x + 5',' ')).evaluate('Probe'),'nil');
  assert.throws(()=>open(source.replace(' | x | x := 2. x + 5',' self')),/No receiver/);
  assert.throws(()=>open(source.replace(' | x | x := 2. x + 5',' Probe := 8')),/Cannot assign to constant/);
  const cls=(name,parent)=>"Class named: '"+name+"' superclass: '"+parent+"' indexedInstanceVariables: #'none' instanceVariableNames: '' classVariableNames: '' sharedPools: '' classInstanceVariableNames: ''!";
  assert.throws(()=>open("Smalltalk interchangeVersion: '1.0'!"+cls('CycleA','CycleB')+cls('CycleB','CycleA')),/Superclass cycle/);
});

check('A4a exact decimal arithmetic and floating-point precision survive image restore', () => {
  const heap=new VM.ImageHeap(),cc=new CC.MethodCompiler(heap);
  const run=expression=>{
    cc.compile('Object','a4Probe\n ^ '+expression,{install:true});
    return UI.invoke(heap,heap.object,'a4Probe');
  };
  assert.equal(heap.display(run('0.10s2 + 0.2s')), '0.30s2');
  assert.equal(heap.display(run('2 + 0.125s3')), '2.125s3');
  assert.equal(heap.display(run('-1.235s2')), '-1.24s2');
  assert.equal(heap.display(run('1s2 / 3')), '0.33s2');
  assert.equal(heap.display(run('0.125s3 asFraction')), '1/8');
  assert.equal(heap.display(run('Fraction numerator: 6 denominator: 8')), '3/4');
  assert.equal(run('[(Fraction numerator: 1 denominator: 0)] on: ZeroDivide do: [:e | 7]'),7);
  assert.equal(heap.display(run('1.0d2 + 0.5e0')), '100.5');
  assert.equal(heap.classOf(run('1.0q-2')), 'FloatD');
  assert.equal(run('FloatE precision'),24);
  assert.equal(run('FloatD precision'),53);
  assert.equal(run('FloatQ radix'),2);
  assert.equal(heap.classOf(run('1.0d-310 asFraction')), 'Fraction');
  assert.equal(run('9007199254740993 = 9.007199254740992d15'),heap.false);
  const decimal=run('0.30s2');
  heap.setGlobal('SavedDecimal',decimal);
  heap.setGlobal('SavedWide',run('1.000000000000001d0'));
  const image=JSON.parse(JSON.stringify(IO.save(heap)));
  const reopened=IO.restore(image).heap;
  assert.equal(reopened.display(reopened.readAssociation(reopened.associations.get('SavedDecimal'))),'0.30s2');
  assert.equal(reopened.display(reopened.readAssociation(reopened.associations.get('SavedWide'))),'1.000000000000001');
  image.heap.objects.find(o=>o.ref===decimal).slots.find(pair=>pair[0]==='scale')[1]=351;
  assert.throws(()=>IO.restore(image),/invalid scaled decimal/);
});

check('A4a short-circuit Boolean, Character and Symbol protocols', () => {
  const heap=new VM.ImageHeap(),cc=new CC.MethodCompiler(heap);
  const run=source=>{
    cc.compile('Object','a4Fundamental\n'+source,{install:true});
    return UI.invoke(heap,heap.object,'a4Fundamental');
  };
  assert.equal(run(' ^ false and: [1 / 0]'),heap.false);
  assert.equal(run(' ^ true or: [1 / 0]'),heap.true);
  assert.equal(run(' false or: [ ^ 8 ]. ^ 9'),8);
  assert.equal(run(' ^ true not'),heap.false);
  assert.equal(run(' ^ 1 isKindOf: Number'),heap.true);
  assert.equal(run(' ^ 1 isMemberOf: Number'),heap.false);
  assert.equal(run(' ^ 1 isMemberOf: SmallInteger'),heap.true);
  assert.equal(run(' ^ (Character codePoint: 65) = $A'),heap.true);
  assert.equal(run(' ^ Character lf codePoint'),10);
  assert.equal(heap.display(run(' ^ (Character codePoint: 128512) asString')),"'😀'");
  assert.equal(run(" ^ #'hello world' = #'hello world'"),heap.true);
  assert.equal(heap.display(run(' ^ #at:put: asString')),"'at:put:'");
});

check('Package panel export, import and error recovery', async () => {
  const elements = new Map();
  function element(id) {
    if (!elements.has(id)) elements.set(id, {
      listeners: new Map(),
      setAttribute() {},
      style: {},
      getContext() { return {fillRect() {}, strokeRect() {}}; },
      getBoundingClientRect() { return {left: 0, top: 0, width: 256, height: 160}; },
      value: '', files: [],
      addEventListener(event, handler) { this.listeners.set(event, handler); },
      replaceChildren(...options) { this.options = options; this.value = options[0]?.value ?? ''; },
      click() { return this.listeners.get('click')?.(); },
    });
    return elements.get(id);
  }
  context.document = {getElementById: element};
  context.Option = class { constructor(label, value) { this.label = label; this.value = value; } };
  let download;
  context.ST80StudioSessionIO = {download: (name, text) => { download = {name, text}; }};
  element('packageSamples').textContent = JSON.stringify(fixtures);
  element('pkgSample').value = 'BudgetTracker';
  const panel = modules.find(source => source.includes("const exportButton = $('pkgExportSource')"));
  new vm.Script(panel).runInContext(context);
  element('pkgRunSample').click();
  element('pkgExportSource').click();
  assert.equal(download.name, 'studio.examples.budget-tracker-1.0.0.st');
  assert.match(download.text, /^!studio-package 1/);
  const input = element('pkgFile');
  const importFile = (filename, text) => {
    input.files = [{name: filename, size: Buffer.byteLength(text), text: async () => text}];
    return input.listeners.get('change')();
  };
  await importFile(download.name, download.text);
  assert.match(element('pkgIdentity').textContent, /Budget Tracker/);
  await importFile('bad.st', 'unsupported');
  assert.match(element('pkgStatus').textContent, /bad\.st:1:1/);
  element('pkgExportSource').click();
  assert.equal(download.name, 'studio.examples.budget-tracker-1.0.0.st');
  element('pkgSample').value = 'GuessingGame';
  element('pkgInstallSample').click();
  assert.match(element('pkgStatus').textContent, /Installed Guessing Game/);
  element('pkgInstallFile').click();
  await importFile('GameScore.st', sourceIO.fileOut(fixture('GameScore')));
  assert.match(element('pkgDetails').textContent, /Requires: studio.examples.guessing-game 1.0.0/);
  element('launcherApp').value = 'studio.examples.game-score';
  element('launchApp').click();
  assert.match(element('pkgIdentity').textContent, /Game Score.*Untitled/);
  const submit = id => element(id).listeners.get('submit')({preventDefault() {}});
  const originalProject = element('projectList').value;
  const guessMethod = element('pkgMethod').options.find(option => option.label === 'guess:').value;
  element('pkgMethod').value = guessMethod;
  element('pkgArgs').value = '7';
  submit('pkgSend');
  assert.match(element('pkgOutput').textContent, /Correct/);
  element('appInspect').click();
  assert.match(element('pkgOutput').textContent, /tries = 1/);
  element('appSource').click();
  assert.match(element('pkgOutput').textContent, /GuessingGame >> guess:/);
  element('appTrace').click();
  assert.match(element('pkgOutput').textContent, /bytecodes/);
  element('appOutput').click();
  element('projectName').value = 'Budget Lab';
  submit('projectCreate');
  assert.equal(element('pkgDetails').textContent, 'No packages installed.');
  element('pkgSample').value = 'BudgetTracker';
  element('pkgInstallSample').click();
  element('projectSave').click();
  assert.equal(download.name, 'Budget-Lab.st80project.json');
  const savedProject = download;
  element('projectList').value = originalProject;
  element('projectList').listeners.get('change')();
  assert.match(element('pkgIdentity').textContent, /Game Score/);
  assert.match(element('pkgOutput').textContent, /Correct/);
  assert.equal(element('pkgMethod').value, guessMethod);
  assert.equal(element('pkgArgs').value, '7');
  element('pkgMethod').value = element('pkgMethod').options.find(option => option.label === 'score').value;
  element('pkgArgs').value = '';
  submit('pkgSend');
  assert.match(element('pkgOutput').textContent, /score → 99/);

  const projectInput = element('projectFile');
  projectInput.files = [{name: 'bad.st80project.json', size: 1, text: async () => '{'}];
  await projectInput.listeners.get('change')();
  assert.match(element('pkgStatus').textContent, /bad.st80project.json:/);
  assert.match(element('pkgIdentity').textContent, /Game Score/);
  projectInput.files = [{name: savedProject.name, size: Buffer.byteLength(savedProject.text), text: async () => savedProject.text}];
  await projectInput.listeners.get('change')();
  assert.match(element('pkgDetails').textContent, /BudgetTracker/);
  element('projectList').value = originalProject;
  element('projectList').listeners.get('change')();
  element('pkgInstalled').value = 'studio.examples.guessing-game';
  element('pkgRemove').click();
  assert.match(element('pkgStatus').textContent, /Remove dependent package/);
  assert.match(element('pkgIdentity').textContent, /Game Score/);
  element('pkgInstalled').value = 'studio.examples.game-score';
  element('pkgRemove').click();
  assert.match(element('pkgStatus').textContent, /Removed Game Score/);
  assert.equal(element('pkgSendBtn').disabled, true);
  element('sampleAppsProject').textContent = JSON.stringify(sampleProject);
  element('projectSamples').click();
  assert.match(element('pkgDetails').textContent, /PixelPad/);
  element('launchApp').click();
  assert.equal(element('appDisplayPane').hidden, false);
  const canvas = element('appCanvas');
  canvas.listeners.get('click')({clientX: 248, clientY: 152});
  assert.equal(element('appPixelStatus').textContent, 'Pixel 31, 19 · Ink');
  const keyboard = key => canvas.listeners.get('keydown')({key, preventDefault() {}});
  keyboard('ArrowLeft');
  assert.equal(element('appPixelStatus').textContent, 'Pixel 30, 19 · Blank');
  keyboard('Enter');
  assert.equal(element('appPixelStatus').textContent, 'Pixel 30, 19 · Ink');
  const sampleIndex = element('projectList').value;
  element('projectList').value = originalProject;
  element('projectList').listeners.get('change')();
  element('projectList').value = sampleIndex;
  element('projectList').listeners.get('change')();
  assert.equal(element('appPixelStatus').textContent, 'Pixel 30, 19 · Ink');
  const checkpoints = new Map();
  context.localStorage = {getItem: key => checkpoints.get(key), setItem: (key, value) => checkpoints.set(key, value)};
  element('projectSnapshot').click();
  assert.match(download.name, /Sample-Apps-Live/);
  assert.match(element('pkgStatus').textContent, /checkpointed/);
  element('projectRecover').click();
  assert.match(element('pkgStatus').textContent, /Recovered Sample Apps/);
  assert.equal(element('appPixelStatus').textContent, 'Pixel 30, 19 · Ink');
  return 'Actual panel handlers with simulated file input and download';
});

function a4bRun(heap,source){
  new CC.MethodCompiler(heap).compile('Object','a4bProbe\n'+source,{install:true});
  return UI.invoke(heap,heap.object,'a4bProbe');
}
check('A4b collections honor Smalltalk equality, identity and non-local return', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run("^ (Set with: 'word' with: ('wo' , 'rd') with: 5 with: 5.0) size"),2);
  assert.equal(run("^ #(1 2 3) includes: 2.0"),h.true);
  assert.equal(run("^ (Bag with: 1 with: 2 with: 1) occurrencesOf: 1"),2);
  assert.equal(run("| b | b := Bag with: 2 with: 2. b remove: 2. ^ b size"),1);
  assert.equal(run("^ (Set with: 3) detect: [:n | n = 9] ifNone: [17]"),17);
  assert.equal(run("(Bag with: 2) do: [:n | ^ n + 5]. ^ 0"),7);
  const source=name=>"| d a b | a := 'key' copy. b := 'key' copy. d := "+name+" new. d at: a put: 4. d at: b put: 9. ^ d size";
  assert.equal(run(source('Dictionary')),1);
  assert.equal(run(source('IdentityDictionary')),2);
  assert.equal(run("| d | d := IdentityDictionary new. d at: #k put: 6. ^ d removeKey: #k ifAbsent: [0]"),6);
  assert.equal(run("| d | d := Dictionary new. d at: 1 put: 8. ^ d at: 1.0 ifAbsent: [0]"),8);
});
check('A4b ordered and bounded collections support factories, copies and iteration', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(h.display(run('^ (SortedCollection with: 7 with: 1 with: 3) asArray')),'#(1 3 7)');
  assert.equal(run('| s | s := SortedCollection sortBlock: [:a :b | a > b]. s addAll: #(2 1 4). ^ s first'),4);
  assert.equal(run('^ (Interval from: 9 to: 2 by: -2) inject: 0 into: [:sum :n | sum + n]'),24);
  assert.equal(run('^ (Interval from: 9 to: 2) size'),0);
  assert.throws(()=>run('^ Interval from: 1 to: 2 by: 0'),/nonzero/);
  assert.equal(run('| a b | a := OrderedCollection with: 1 with: 2. b := a copy. b at: 1 put: 9. ^ a first'),1);
  assert.equal(run('^ (ByteArray with: 0 with: 255) last'),255);
  assert.throws(()=>run('^ ByteArray with: 256'),/byte/);
});
check('A4b collection streams support zero-based cursors, peek, EOF and replacement', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run('^ (ReadStream on: #(1 2)) position'),0);
  assert.equal(run('^ (ReadWriteStream with: #(1 2)) position'),2);
  assert.equal(h.display(run("^ (WriteStream with: 'ab') contents")),"'ab'");
  assert.equal(h.display(run("| s | s := ReadStream on: 'ab/cd'. s upTo: $/. ^ s upToEnd")),"'cd'");
  assert.equal(run('| s | s := ReadStream on: #(1 2). s peek. ^ s position'),0);
  assert.equal(run('| s | s := ReadStream on: #(1 2). s setToEnd. ^ s next'),h.nil);
  assert.throws(()=>run('| s | s := ReadStream on: #(1). s position: 2. ^ s'),/out of bounds/);
  assert.equal(h.display(run("| s | s := ReadStream on: 'a😀b'. s next. ^ s upToEnd")),"'😀b'");
  assert.equal(h.display(run("| s | s := WriteStream on: ''. s nextPutAll: 'xyz'. ^ s contents")),"'xyz'");
  assert.equal(h.display(run('| s a | a := #(1 2 3) copy. s := ReadWriteStream on: a. s position: 1. s nextPut: 9. ^ a')),'#(1 9 3)');
  assert.equal(h.display(run("| s | s := WriteStream on: ''. s nextPutAll: 'abc'. s position: 1. s nextPut: $Z. ^ s contents")),"'aZc'");
  assert.equal(h.display(run('| s | s := WriteStream on: (ByteArray new). s nextPut: 255. ^ s contents')),'ByteArray #[255]');
});
check('A4a writer layout migrates with its append position', () => {
  const h=new VM.ImageHeap();
  const ref=a4bRun(h,'| w | w := WriteStream new. w nextPut: 9. ^ w');
  h.setGlobal('SavedWriter',ref);
  const image=JSON.parse(JSON.stringify(IO.save(h)));
  image.studioVersion='1.2.0-ansi.5';
  image.heap.classes.find(c=>c.name==='WriteStream').ownSlots=['collection'];
  image.heap.objects.find(o=>o.ref===ref).slots=image.heap.objects.find(o=>o.ref===ref).slots.filter(([name])=>name!=='position');
  const reopened=IO.restore(image).heap;
  assert.equal(a4bRun(reopened,'^ SavedWriter position'),1);
  assert.equal(a4bRun(reopened,'SavedWriter nextPut: 5. ^ SavedWriter contents size'),2);
});
check('A4b dates and durations handle offsets, leap days, rollover and image restore', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  const leap='DateAndTime year: 2024 month: 2 day: 29 hour: 1 minute: 30 second: 0 offset: (Duration seconds: 7200)';
  assert.equal(run('^ ('+leap+') dayOfYear'),60);
  assert.equal(run('^ ('+leap+') asUTC dayOfMonth'),28);
  assert.equal(run('^ ('+leap+') asUTC hour'),23);
  assert.equal(run('| d | d := '+leap+'. ^ d = d asUTC'),h.true);
  assert.equal(run('| d | d := '+leap+'. ^ ((d + (Duration seconds: 10)) - d) asSeconds'),10);
  assert.equal(h.display(run('^ (Duration seconds: 1.25s2) asSeconds')),'5/4');
  assert.throws(()=>run('^ '+leap.replace('2024','2023')),/Invalid calendar/);
  h.setGlobal('SavedDate',run('^ '+leap));
  const restored=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(a4bRun(restored,'^ SavedDate offset asSeconds'),7200);
});
check('A4b UTF-8 named files reopen across handles and native image restore', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  run("| f | f := FileStream write: 'note'. f nextPutAll: 'café@😀'. f close. ^ nil");
  assert.equal(h.display(run("^ (FileStream read: 'note') contents")),"'café@😀'");
  const r=run("| f | f := FileStream read: 'note'. f setToEnd. ^ f");
  h.setGlobal('SavedFileHandle',r);
  const restored=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(a4bRun(restored,'^ SavedFileHandle position'),6);
  assert.equal(restored.display(a4bRun(restored,"^ (FileStream read: 'note') contents")),"'café@😀'");
  assert.equal(a4bRun(restored,"^ [FileStream read: 'unknown'] on: FileError do: [:error | 12]"),12);
});
check('A4b binary modes, overwrite protection, flush, stale writers and closed handles', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  run("| f | f := FileStream write: 'bytes' mode: #create check: true type: #binary. f nextPut: 255. f flush. f close. ^ nil");
  assert.equal(run("^ (FileStream read: 'bytes' check: false type: #binary) next"),255);
  assert.equal(run("^ [FileStream write: 'bytes' mode: #create check: true type: #binary] on: FileError do: [:e | 13]"),13);
  assert.equal(run("| f | f := FileStream read: 'bytes' check: false type: #binary. f close. ^ [f next] on: FileError do: [:e | 14]"),14);
  assert.equal(run("| a b | a := FileStream openBinary: 'bytes' mode: #readWrite. b := FileStream openBinary: 'bytes' mode: #readWrite. a nextPut: 11. a close. b nextPut: 22. ^ [b close] on: FileError do: [:e | 15]"),15);
  run("| a | a := FileStream write: 'bytes' mode: #append check: false type: #binary. a reset. a nextPut: 22. a close. ^ nil");
  assert.equal(h.display(run("^ (FileStream read: 'bytes' check: false type: #binary) contents")),'ByteArray #[22]');
});

check('A5 dynamic sends use ordinary dispatch, closures, primitives and typed failed-message handling', () => {
  const h=new VM.ImageHeap();
  const run=source=>a4bRun(h,source);
  assert.equal(run('^ StudioOrigin perform: #x'),120);
  assert.equal(run('^ 7 perform: #+ with: 5'),12);
  assert.equal(run('^ [:a :b | a * b] perform: #value:value: withArguments: #(6 7)'),42);
  assert.equal(run('^ self perform: #perform:with: withArguments: #(#perform: #yourself)'),h.object);
  assert.equal(run('^ StudioOrigin respondsTo: #x'),h.true);
  assert.equal(run('^ 7 respondsTo: #+'),h.true);
  assert.equal(run('^ StudioOrigin respondsTo: #missingSelector'),h.false);
  assert.equal(run('^ [self perform: #absent: with: 41] on: MessageNotUnderstood do: [:e | e resume: 18]'),18);
  assert.throws(()=>run('^ self perform: #+'),/argument count/);
  assert.throws(()=>run("^ self perform: 'class'"),/Symbol/);
});
check('A5 Transcript works through Smalltalk methods and survives image save without cross-image output', () => {
  const h=new VM.ImageHeap(),other=new VM.ImageHeap();
  a4bRun(h,"Transcript show: ('hel' , 'lo'); cr; nextPut: $!. ^ nil");
  assert.equal(h.display(a4bRun(h,'^ Transcript contents')),"'hello\n!'");
  assert.equal(other.display(a4bRun(other,'^ Transcript contents')),"''");
  const reopened=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(reopened.display(a4bRun(reopened,'^ Transcript contents')),"'hello\n!'");
  assert.equal(reopened.display(a4bRun(reopened,'Transcript clear. ^ Transcript contents')),"''");
});
check('A5 reads and writes the 127th inherited named slot through SIF, compiler, debugger and image restore', () => {
  const longName='Boundary'+'X'.repeat(192);
  const slots=Array.from({length:126},(_,i)=>'slot'+i).join(' ');
  const sif=[
    "Smalltalk interchangeVersion: '1.0'!",
    "Class named: '"+longName+"' superclass: 'Object' indexedInstanceVariables: #'none' instanceVariableNames: '"+slots+"' classVariableNames: '' sharedPools: '' classInstanceVariableNames: ''!",
    "Class named: 'WideChild' superclass: '"+longName+"' indexedInstanceVariables: #'none' instanceVariableNames: 'farSlot' classVariableNames: '' sharedPools: '' classInstanceVariableNames: ''!",
    "WideChild method!writeRead: aValue\n farSlot := aValue. ^ farSlot!"
  ].join('\n');
  const opened=context.ST80SIF.open(sif);
  assert.equal(opened.evaluate('WideChild new writeRead: 37'),'37');
  assert.equal(context.ST80SIF.open(opened.export()).evaluate('WideChild new writeRead: 42'),'42');
  const h=new VM.ImageHeap();
  h.defineClass(longName,'Object',slots.split(' '));
  h.defineClass('WideChild',longName,['farSlot']);
  new CC.MethodCompiler(h).compile('WideChild','writeRead: aValue\n farSlot := aValue. ^ farSlot',{install:true});
  assert.equal(h.slotsFor('WideChild').length,127);
  const ref=a4bRun(h,'^ WideChild new');
  assert.equal(UI.invoke(h,ref,'writeRead:',[37]),37);
  const method=h.lookup('WideChild','writeRead:');
  assert(VM.disassemble(method).some(b=>b.kind==='storeWideSlot'&&b.implemented&&b.operand===126));
  assert(VM.disassemble(method).some(b=>b.kind==='pushSlot'&&b.implemented&&b.operand===126));
  h.setGlobal('WideExample',ref);
  const restored=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(restored.readSlot(ref,126),37);
  assert.equal(UI.invoke(restored,ref,'writeRead:',[57]),57);
});
check('A5 package behavior supports 1,000 methods', () => {
  const manifest=fixture('GuessingGame');
  const methods=manifest.classes[0].methods;
  while(methods.length<1000)methods.push({side:'instance',source:'boundary'+methods.length+'\n ^ 73'});
  assert.equal(Packages.open(manifest).send('boundary999',[]),'73');
  methods.push({side:'instance',source:'boundary1000\n ^ 73'});
  assert.throws(()=>Packages.open(manifest),/1,000 methods/);
});
check('A5 migrates and resaves a live project produced by the accepted A4b executable', () => {
  const source=fs.readFileSync(path.join(root,'samples','Legacy_A4b_Project.st80project.json'),'utf8');
  assert.match(source,/"studioVersion"\s*:\s*"1\.2\.0-ansi\.6"/);
  const io=context.ST80Projects,p=io.load(source,'Legacy A4b project');
  assert.equal(p.run.app.display().pixels[7*32+5],1);
  assert.equal(p.run.app.send('inkCount',[]),'1');
  const saved=io.save(p,true,p.run);
  assert.match(saved.text,/"studioVersion"\s*:\s*"1\.2\.0"/);
  assert.equal(io.load(saved.text,'A5 resave').run.app.send('inkCount',[]),'1');
});

check('A5.1 indexed arrays and byte arrays allocate, index and report size at 65535', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const cls of ['Array','ByteArray']){
    for(const selector of ['new:','basicNew:']){
      const ref=run('| a | a := '+cls+' '+selector+' 65535. a at: 65535 put: 77. ^ a');
      h.setGlobal('WideSequence',ref);
      for(const msg of ['size','basicSize','instSize'])
        assert.equal(h.integerBigInt(run('^ WideSequence '+msg)),65535n);
      for(const msg of ['at:','basicAt:','instVarAt:'])
        assert.equal(run('^ WideSequence '+msg+' 65535'),77);
      assert.equal(run('^ WideSequence instVarAt: 65535 put: 81'),81);
      assert.equal(run('^ WideSequence basicAt: 65535'),81);
      assert.throws(()=>run('^ WideSequence at: 65536'));
      assert.throws(()=>run('^ '+cls+' '+selector+' 65536'));
    }
  }
});
check('A5.1 native image round-trip preserves wide indexed data and rejects oversized bytes', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [name,cls] of [['WideArray','Array'],['WideBytes','ByteArray']]){
    h.setGlobal(name,run('| a | a := '+cls+' new: 65535. a at: 65535 put: 99. ^ a'));
  }
  const img=JSON.parse(JSON.stringify(IO.save(h)));
  const reopened=IO.restore(img).heap;
  assert.equal(a4bRun(reopened,'^ WideArray at: 65535'),99);
  assert.equal(a4bRun(reopened,'^ WideBytes at: 65535'),99);
  img.heap.objects.find(o=>o.bytes?.length===65535).bytes.push(0);
  assert.throws(()=>IO.restore(img),/invalid ByteArray bytes/);
});
check('A5.1 equivalent numeric and text values agree on hash', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [a,b] of [['1','1.0e0'],['1','1.00s2'],['-3','-3.0d0'],['1 / 8','0.125d0'],
    ['0','-0.0d0'],['1.0d-310','1.0d-310 asFraction'],["'é'", "'é' copy"],["$é",'Character value: 233']]){
    assert.equal(run('^ ('+a+') = ('+b+')'),h.true);
    assert.equal(run('^ ('+a+') hash = ('+b+') hash'),h.true);
  }
  assert.equal(run("^ 'abc' hash = ('a' , 'bc') hash"),h.true);
});
check('A5.1 accepted A5 snapshot restores and resaves using the new build', () => {
  const source=fs.readFileSync(path.join(root,'samples','Legacy_A5_Project.st80project.json'),'utf8');
  assert.match(source,/"studioVersion"\s*:\s*"1\.2\.0-ansi\.7"/);
  const io=context.ST80Projects,p=io.load(source,'Legacy A5 project');
  assert.equal(p.run.app.send('average',[]),'5/2');
  const saved=io.save(p,true,p.run);
  assert.match(saved.text,/"studioVersion"\s*:\s*"1\.2\.0"/);
  assert.equal(io.load(saved.text,'A5.1 resave').run.app.send('average',[]),'5/2');
});

check('A5.2 SIF imports, exports and executes both indexed layouts and inherited layouts', () => {
  const source=fs.readFileSync(path.join(root,'samples','SifIndexed.sif'),'utf8');
  const open=context.ST80SIF.open;
  for(const p of [open(source),open(open(source).export())]){
    assert.equal(p.classCount,4);
    assert.equal(p.evaluate('(IndexedRecord basicNew: 2) pick: 2'),'nil');
    assert.equal(p.evaluate('(IndexedRecordChild basicNew: 3) remember: 47 at: 3'),'47');
    assert.equal(p.evaluate('(IndexedRecordChild basicNew: 3) instSize'),'5');
    assert.equal(p.evaluate('IndexedRecordChild basicNew basicSize'),'0');
    assert.equal(p.evaluate('(IndexedOctetsChild basicNew: 65535) initialByte'),'0');
    assert.equal(p.evaluate('(IndexedOctetsChild basicNew: 65535) lastByte: 255'),'255');
    assert.throws(()=>p.evaluate('(IndexedOctetsChild basicNew: 1) lastByte: 256'),/Primitive operation failed/);
    assert.throws(()=>p.evaluate('(IndexedOctets basicNew: 2) basicAt: 3'),/Primitive operation failed/);
    assert.throws(()=>p.evaluate('IndexedRecord basicNew: 65535'),/Primitive operation failed/);
  }
});
check('A5.2 SIF rejects unknown and incompatible indexed layouts', () => {
  const source=fs.readFileSync(path.join(root,'samples','SifIndexed.sif'),'utf8'),open=context.ST80SIF.open;
  assert.throws(()=>open(source.replace("#'object'","#'word'")),/Unknown indexed instance variable representation/);
  assert.throws(()=>open(source.replace("'IndexedOctets' indexedInstanceVariables: #'none'","'IndexedOctets' indexedInstanceVariables: #'object'")),/Incompatible indexed layout/);
  assert.throws(()=>open(source.replace("'IndexedOctets' indexedInstanceVariables: #'none' instanceVariableNames: ''","'IndexedOctets' indexedInstanceVariables: #'none' instanceVariableNames: 'slot'")),/Byte indexed classes cannot/);
});
check('A5.2 indexed payloads survive garbage collection and native image reload', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  h.defineClass('IndexedBox','Object',['label'],'object');
  h.defineClass('IndexedBoxChild','IndexedBox',[]);
  h.defineClass('IndexedBuffer','Object',[],'byte');
  h.setGlobal('SavedBox',run("| a | a := IndexedBoxChild basicNew: 6. a instVarAt: 1 put: 14. a basicAt: 6 put: ('p' , 'ayload'). ^ a"));
  h.setGlobal('SavedBuffer',run('| b | b := IndexedBuffer basicNew: 4. b basicAt: 4 put: 232. ^ b'));
  IO.collect(h);
  const img=JSON.parse(JSON.stringify(IO.save(h)));
  const reopened=IO.restore(img).heap;
  assert.equal(a4bRun(reopened,'^ SavedBox instVarAt: 1'),14);
  assert.equal(reopened.display(a4bRun(reopened,'^ SavedBox basicAt: 6')),"'payload'");
  assert.equal(a4bRun(reopened,'^ SavedBuffer basicAt: 4'),232);
  const box=img.heap.objects.find(o=>o.className==='IndexedBoxChild');
  const data=box.indexed;
  delete box.indexed;
  assert.throws(()=>IO.restore(img),/missing indexed object payload/);
  box.indexed=data;
  img.heap.objects.find(o=>o.className==='IndexedBuffer').bytes[0]=256;
  assert.throws(()=>IO.restore(img),/invalid ByteArray bytes/);
});

check('A5.3 precise duration construction rounds once in milliseconds', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(h.display(run('^ (Duration hours: 0.0001s4) asSeconds')),'9/25');
  assert.equal(h.display(run('^ (Duration minutes: 0.0001s4) asSeconds')),'3/500');
  assert.equal(h.display(run('^ (Duration seconds: -0.0005s4) asSeconds')),'-1/1000');
  assert.equal(h.display(run('^ (Duration seconds: 0.0005s4) asSeconds')),'1/1000');
  assert.equal(run('^ Duration zero asSeconds'),0);
  assert.equal(h.display(run('^ (Duration hours: 1000000000000000) asSeconds')),'3600000000000000000');
});
check('A5.3 duration multiplication and division preserve units and signal typed zero divide', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(h.display(run('^ ((Duration seconds: 3) * (1 / 2)) asSeconds')),'3/2');
  assert.equal(h.display(run('^ ((Duration seconds: 5) / 2) asSeconds')),'5/2');
  assert.equal(h.display(run('^ (Duration seconds: 5) / (Duration seconds: 2)')),'5/2');
  assert.equal(run('^ [(Duration seconds: 5) / 0] on: ZeroDivide do: [:e | 41]'),41);
  assert.equal(run('^ [(Duration seconds: 5) / Duration zero] on: ZeroDivide do: [:e | 42]'),42);
});
check('A5.3 civil date accessors and daylight-saving gaps and overlaps', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  const old=process.env.TZ;
  process.env.TZ='America/New_York';
  try{
    const fold='DateAndTime year: 2024 month: 11 day: 3 hour: 1 minute: 30 second: 0';
    assert.equal(run('^ ('+fold+') asUTC hour24'),5);
    assert.equal(run('^ ('+fold+') offset asSeconds'),-14400);
    const explicit=fold+' offset: (Duration hours: -5)';
    assert.equal(run('^ ('+explicit+') asUTC hour24'),6);
    assert.equal(h.integerBigInt(run('^ ('+explicit+') asLocal offset asSeconds')),-18000n);
    const midnight='DateAndTime year: 2024 month: 3 day: 10 hour: 0 minute: 15 second: 0';
    assert.equal(run('^ ('+midnight+') hour12'),12);
    assert.equal(h.display(run('^ ('+midnight+') monthName')),"'March'");
    const gap='DateAndTime year: 2024 month: 3 day: 10 hour: 2 minute: 30 second: 0';
    assert.throws(()=>run('^ '+gap),/Local civil time does not exist/);
    assert.equal(run('^ ('+gap+' offset: (Duration hours: -5)) asUTC hour24'),7);
  }finally{
    if(old===undefined)delete process.env.TZ;else process.env.TZ=old;
  }
});

check('A5.4 read stream matching honors Smalltalk equality, cursor movement and EOF', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run('^ (ReadStream on: #(1)) peekFor: 1.0d0'),h.true);
  assert.equal(run('^ (ReadStream on: #(nil)) peekFor: nil'),h.true);
  assert.equal(run('^ (ReadStream on: #()) peekFor: nil'),h.false);
  assert.equal(run('| s | s := ReadStream on: #(1 2). s peekFor: 1. ^ s position'),0);
  assert.equal(run('| s | s := ReadStream on: #(1 2). s nextMatchFor: 3. ^ s next'),2);
  assert.equal(run('| s | s := ReadStream on: #(1 2 3). s skipTo: 2. ^ s next'),3);
  assert.equal(run('| s | s := ReadStream on: #(1 2 3). s skipTo: 4. ^ s atEnd'),h.true);
  assert.equal(run('| s | s := ReadStream on: #(1 2 3). s skip: 100. ^ s position'),3);
  assert.equal(h.display(run("^ (ReadStream on: 'é🍎b') upTo: $b")),"'é🍎'");
  const cc=new CC.MethodCompiler(h);
  h.defineClass('MatchingMarker','Object',[]);
  cc.compile('MatchingMarker','= other\n ^ other = 99',{install:true});
  assert.equal(run('| marker stream | marker := MatchingMarker new. stream := ReadStream on: (Array with: marker). ^ stream peekFor: 99'),h.true);
});
check('A5.4 file stream matching and Unicode append preserve character positions across image restore', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  run("| f | f := FileStream write: 'note'. f nextPutAll: 'é🍎|other'. ^ f close");
  assert.equal(run("^ (FileStream read: 'note') isBinary"),h.false);
  assert.equal(run("^ (FileStream read: 'note' check: false type: #binary) isBinary"),h.true);
  assert.equal(h.display(run("^ (FileStream read: 'note') upTo: $|")),"'é🍎'");
  assert.equal(run("| f | f := FileStream read: 'note'. f skipTo: $|. ^ f peekFor: $o"),h.true);
  const ref=run("^ FileStream write: 'note' mode: #append");
  h.setGlobal('SavedAppend',ref);
  assert.equal(run('^ SavedAppend position'),8);
  assert.equal(run('^ SavedAppend atEnd'),h.true);
  const restored=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  a4bRun(restored,"SavedAppend nextPutAll: '¢'. ^ SavedAppend close");
  assert.equal(restored.display(a4bRun(restored,"^ (FileStream read: 'note') contents")),"'é🍎|other¢'");
  assert.equal(a4bRun(restored,"(FileStream read: 'note') do: [:ch | ^ ch codePoint]. ^ 0"),233);
});
check('A5.4 file commits preserve concurrent changed writers across a clean flush or close', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(h.display(run("| c a b | c := FileStream write: 'note'. c nextPutAll: 'seed'. c close. a := FileStream open: 'note' mode: #readWrite. b := FileStream open: 'note' mode: #readWrite. a flush. b nextPut: $S. b close. a close. ^ (FileStream read: 'note') contents")),"'Seed'");
  run("| c | c := FileStream openBinary: 'raw' mode: #create. c nextPut: 255. ^ c close");
  assert.equal(run("^ [FileStream read: 'raw'] on: FileError do: [:e | 42]"),42);
  assert.equal(run("^ (FileStream read: 'raw' check: false type: #binary) next"),255);
});
check('A5.4 accepted A5.3 snapshot migrates its kernel method inventory and resaves', () => {
  const source=fs.readFileSync(path.join(root,'samples','Legacy_A5_3_Project.st80project.json'),'utf8');
  assert.match(source,/"studioVersion"\s*:\s*"1\.2\.0-ansi\.10"/);
  const io=context.ST80Projects,p=io.load(source,'Legacy A5.3 project');
  assert.equal(p.run.app.send('average',[]),'5/2');
  const saved=io.save(p,true,p.run);
  assert.match(saved.text,/"studioVersion"\s*:\s*"1\.2\.0"/);
  assert.equal(io.load(saved.text,'A5.4 resave').run.app.send('average',[]),'5/2');
});

check('A5.5 printString returns Smalltalk Strings and printOn sends one Character at a time', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [expression,expected] of [['(1 / 8)','1/8'],['nil','nil'],['true','true'],['$🍎','$🍎'],['Object new','a Object'],['Array new: 65535','Array (65535 elements)']]){
    const ref=run('^ ('+expression+') printString');
    assert.equal(h.classOf(ref),'String');
    assert.equal(h.fetch(ref).text,expected);
  }
  assert.equal(h.fetch(run("^ 'can''t' printString")).text,"'can''t'");
  h.defineClass('PrintableFixture','Object',[]);
  h.defineClass('CharacterSink','Object',['value']);
  const cc=new CC.MethodCompiler(h);
  cc.compile('PrintableFixture',"printString\n ^ 'é🍎'",{install:true});
  cc.compile('CharacterSink',"nextPut: ch\n value isNil ifTrue: [value := '']. value := value , ch asString. ^ ch",{install:true});
  cc.compile('CharacterSink',"contents\n ^ value",{install:true});
  const r=run('| p sink | p := PrintableFixture new. sink := CharacterSink new. p printOn: sink. ^ sink contents');
  assert.equal(h.fetch(r).text,'é🍎');
});
check('A5.5 stream reflection agrees with ordinary and computed dispatch', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run('^ ReadStream respondsTo: #on:'),h.true);
  assert.equal(run('^ ReadStream respondsTo: #with:'),h.false);
  assert.equal(run('^ WriteStream respondsTo: #with:'),h.true);
  assert.equal(run('^ FileStream respondsTo: #write:mode:check:type:'),h.true);
  assert.equal(run('^ FileStream respondsTo: #notAFactory'),h.false);
  assert.equal(run('^ (ReadStream on: #(42)) respondsTo: #peek'),h.true);
  assert.equal(run('^ (ReadStream on: #(42)) perform: #peek'),42);
  assert.equal(run('^ (ReadStream on: #(42)) respondsTo: #peekFor:'),h.true);
  assert.equal(run("^ (FileStream write: 'reflection') respondsTo: #isBinary"),h.true);
  assert.equal(run("^ (FileStream write: 'reflection') perform: #isBinary"),h.false);
  assert.equal(run("^ self respondsTo: #printOn:"),h.true);
});
check('A5.5 project migration loads the accepted A5.4 method inventory', () => {
  const source=fs.readFileSync(path.join(root,'samples','Legacy_A5_4_Project.st80project.json'),'utf8');
  assert.match(source,/"studioVersion"\s*:\s*"1\.2\.0-ansi\.11"/);
  const io=context.ST80Projects,p=io.load(source,'Legacy A5.4 project');
  assert.equal(p.run.app.send('average',[]),'5/2');
  const saved=io.save(p,true,p.run);
  assert.match(saved.text,/"studioVersion"\s*:\s*"1\.2\.0"/);
  assert.equal(io.load(saved.text,'A5.5 resave').run.app.send('average',[]),'5/2');
});

check('A5.6 numeric decomposition preserves numeric representations', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  const cases=[
    ['7','7','0','SmallInteger','SmallInteger'],
    ['5 / 2','2','1/2','SmallInteger','Fraction'],
    ['-5 / 2','-2','-1/2','SmallInteger','Fraction'],
    ['-2.25s2','-2.00s2','-0.25s2','ScaledDecimal','ScaledDecimal'],
    ['-2.25e0','-2.0','-0.25','Float','Float'],
    ['2.25d0','2.0','0.25','FloatD','FloatD'],
  ];
  for(const [x,whole,part,wholeType,partType] of cases){
    const w=run('^ ('+x+') integerPart'),p=run('^ ('+x+') fractionPart');
    assert.equal(h.display(w),whole);
    assert.equal(h.display(p),part);
    assert.equal(h.classOf(w),wholeType);
    assert.equal(h.classOf(p),partType);
    assert.equal(run('^ (('+x+') integerPart + ('+x+') fractionPart) = ('+x+')'),h.true);
  }
});
check('A5.6 reflection exposes accepted numeric selectors and factories without invoking them', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [receiver,selector] of [['0','reciprocal'],['5','integerPart'],['5','asFloatE'],['5','asFloatQ'],['1.05s2','scale'],['FloatD','epsilon'],['FloatE','precision'],['Fraction','numerator:denominator:']]){
    assert.equal(run('^ ('+receiver+') respondsTo: #'+selector),h.true);
  }
  assert.equal(run('^ 5 respondsTo: #scale'),h.false);
  assert.equal(run('^ FloatD respondsTo: #notAFactory'),h.false);
  assert.equal(run('^ FloatD perform: #precision'),53);
  assert.equal(h.display(run('^ (5 / 2) perform: #fractionPart')),'1/2');
  assert.equal(h.display(run('^ Fraction perform: #numerator:denominator: withArguments: #(5 2)')),'5/2');
});
check('A5.6 numeric decomposition works after native image reload', () => {
  const h=new VM.ImageHeap();
  h.setGlobal('SavedDecimal',a4bRun(h,'^ -123456.875s3'));
  const copy=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(copy.display(a4bRun(copy,'^ SavedDecimal perform: #integerPart')),'-123456.000s3');
  assert.equal(copy.display(a4bRun(copy,'^ SavedDecimal fractionPart')),'-0.875s3');
});

check('A5.7 String and Symbol indexing and size agree on Unicode code points', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run("^ 'a🍎z' size"),3);
  assert.equal(run("^ 'a🍎z' basicSize"),3);
  assert.equal(run("^ 'a🍎z' instSize"),3);
  assert.equal(h.integerBigInt(run("^ ('a🍎z' at: 2) codePoint")),127822n);
  assert.equal(h.integerBigInt(run("^ 'a🍎z' basicAt: 2")),127822n);
  assert.equal(h.integerBigInt(run("^ #'a🍎z' instVarAt: 2")),127822n);
  assert.equal(h.fetch(run("^ (#'a🍎z' at: 2) asString")).text,'🍎');
  assert.throws(()=>run("^ 'a🍎z' at: 4"),/out of bounds/);
  assert.throws(()=>run("^ #'a🍎z' basicAt: 2 put: 65"),/Primitive operation failed/);
});
check('A5.7 Unicode writes preserve adjacent characters and image state', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  h.setGlobal('UnicodeText',run("^ 'a🍎z' copy"));
  run('UnicodeText at: 2 put: $é. ^ UnicodeText');
  assert.equal(h.fetch(run('^ UnicodeText')).text,'aéz');
  run('UnicodeText basicAt: 3 put: 128578. ^ UnicodeText');
  assert.equal(h.fetch(run('^ UnicodeText')).text,'aé🙂');
  assert.throws(()=>run('^ UnicodeText basicAt: 2 put: 55296'),/Primitive operation failed/);
  const copy=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(copy.fetch(a4bRun(copy,'^ (UnicodeText at: 3) asString')).text,'🙂');
  assert.equal(a4bRun(copy,'^ UnicodeText size'),3);
});
check('A5.7 integer radix printing cooperates with reflection and normal character-stream sends', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(h.fetch(run('^ -255 printStringRadix: 16')).text,'-FF');
  assert.equal(h.fetch(run('^ 35 printStringRadix: 36')).text,'Z');
  assert.equal(h.fetch(run('^ 18446744073709551615 printStringRadix: 16')).text,'FFFFFFFFFFFFFFFF');
  assert.equal(run('^ 255 respondsTo: #printStringRadix:'),h.true);
  assert.equal(run('^ 1.5d0 respondsTo: #printStringRadix:'),h.false);
  assert.throws(()=>run('^ 5 printStringRadix: 1'),/Radix must/);
  for(const [flag,expected] of [['true','-16rFF'],['false','-FF']]){
    const r=run("| out | out := WriteStream on: ''. -255 printOn: out base: 16 showRadix: "+flag+". ^ out contents");
    assert.equal(h.fetch(r).text,expected);
  }
});

check('A5.9 Boolean and block reflection agrees with computed control sends', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run('^ true respondsTo: #ifTrue:'),h.true);
  assert.equal(run('^ false respondsTo: #and:'),h.true);
  assert.equal(run('^ 5 respondsTo: #ifTrue:'),h.false);
  assert.equal(run('^ true perform: #ifTrue: with: [42]'),42);
  assert.equal(run('^ [42] respondsTo: #value'),h.true);
  assert.equal(run('^ [:a | a] respondsTo: #valueWithArguments:'),h.true);
  assert.equal(run('^ [:a | a] perform: #value: with: 43'),43);
  assert.equal(run('^ [42] respondsTo: #notAControlSelector'),h.false);
});
check('A5.9 Symbol conversion, quoting and recompilation share a live identity', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  assert.equal(run("^ 'é🍎' asSymbol == #'é🍎'"),h.true);
  assert.equal(run("^ #keyword: asSymbol == #keyword:"),h.true);
  assert.equal(run("^ 'keyword:' respondsTo: #asSymbol"),h.true);
  assert.equal(run("^ '' asSymbol == #''"),h.true);
  assert.equal(run("^ 'North' asSymbol == 'north' asSymbol"),h.false);
  const first=run("^ 'same' asSymbol");
  assert.equal(run('^ #same'),first);
  const unrooted=h.newSymbol('collectThis');
  IO.collect(h);
  assert(!h.nodes.has(unrooted));
  const newer=h.newSymbol('collectThis');
  assert.notEqual(newer,unrooted);
  assert.equal(h.newSymbol('collectThis'),newer);
});
check('A5.9 legacy Symbol migration repairs literals, arrays, runtime links and identity-dictionary collisions', () => {
  const saved=JSON.parse(fs.readFileSync(path.join(root,'samples','Legacy_A5_7_Symbols.st80image.json'),'utf8'));
  assert.equal(saved.studioVersion,'1.2.0-ansi.14');
  const {heap:h,runtime}=IO.restore(saved),run=source=>a4bRun(h,source);
  const canonical=run('^ #priorKey');
  assert.equal(run('^ self oldLiteralA'),canonical);
  assert.equal(run('^ self oldLiteralB'),canonical);
  assert.equal(run('^ OldSymbols at: 2'),canonical);
  assert.equal(runtime.selectedValue,canonical);
  assert.equal(runtime.lastValue,canonical);
  assert.equal(run('^ OldDictionary size'),1);
  assert.equal(run('^ OldDictionary at: #priorKey'),22);
  const image=IO.save(h,runtime);
  assert.equal(image.heap.objects.filter(o=>o.className==='Symbol'&&o.text==='priorKey').length,1);
  const after=IO.restore(JSON.parse(JSON.stringify(image)));
  assert.equal(a4bRun(after.heap,"^ 'priorKey' asSymbol == self oldLiteralA"),after.heap.true);
});

check('RC1 preview preserves accepted A5.9 live projects through versioned save and reopen', () => {
  const source=fs.readFileSync(path.join(root,'samples','Accepted_A5_9_Live.st80project.json'),'utf8');
  assert.equal(JSON.parse(source).image.studioVersion,'1.2.0-ansi.15');
  const io=context.ST80Projects, project=io.load(source,'Accepted A5.9');
  assert.equal(project.run.app.send('average',[]),'17/2');
  const saved=io.save(project,true,project.run).text;
  assert.equal(JSON.parse(saved).image.studioVersion,'1.2.0');
  assert.equal(io.load(saved,'RC1 preview resave').run.app.send('average',[]),'17/2');
});

check('RC1 opens and resaves an accepted preview project', () => {
  const name='Accepted_RC1_Preview_Live.st80project.json';
  const source=fs.readFileSync(path.join(root,'samples',name),'utf8');
  assert.equal(JSON.parse(source).image.studioVersion,'1.2.0-rc.0.1');
  const io=context.ST80Projects, project=io.load(source,name);
  assert.equal(project.run.app.send('average',[]),'8');
  const saved=io.save(project,true,project.run).text;
  assert.equal(JSON.parse(saved).image.studioVersion,'1.2.0');
  assert.equal(io.load(saved,'RC1 resave').run.app.send('average',[]),'8');
});

check('A6.1 draft file creation checks honor the full existence and mode matrix', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const exists of [false,true])for(const mode of ['create','append','truncate'])for(const checked of [false,true]){
    const name=[mode,exists,checked].join('-');
    if(exists)run("| f | f := FileStream write: '"+name+"'. f nextPutAll: 'seed'. ^ f close");
    const expr="FileStream write: '"+name+"' mode: #"+mode+" check: "+checked+" type: #text";
    const errors=checked&&(mode==='create'?exists:!exists);
    if(errors){
      assert.equal(run('^ ['+expr+'] on: FileError do: [:e | 77]'),77);
      if(!exists)assert(!context.ST80A4b.externalFiles.names(h).includes(name));
      continue;
    }
    const ref=run('^ '+expr);
    h.setGlobal('ModeFile',ref);
    const append=mode==='append'&&exists;
    assert.equal(run('^ ModeFile position'),append?4:0);
    assert.equal(run('^ ModeFile isEmpty'),append?h.false:h.true);
    assert.equal(run('^ ModeFile isText'),h.true);
    assert.equal(h.display(run('^ ModeFile externalType')),'#text');
    assert.equal(run('^ [ModeFile next] on: FileError do: [:e | 78]'),78);
    run('^ ModeFile close');
    assert.equal(h.display(run("^ (FileStream read: '"+name+"' type: #text) contents")),append?"'seed'":"''");
  }
});
check('A6.1 typed factories, cursor overwrite, line handling and memory close', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  run("| f | f := FileStream write: 'mixed'. f nextPutAll: 'abc'. ^ f close");
  run("| f | f := FileStream write: 'mixed' mode: #append. f position: 1. f nextPut: $Z. ^ f close");
  assert.equal(h.display(run("^ (FileStream read: 'mixed' type: #text) contents")),"'aZc'");
  assert.equal(h.display(run("^ (FileStream read: 'mixed' type: #binary) externalType")),'#binary');
  assert.equal(h.display(run("^ (FileStream read: 'mixed' type: #binary) contents")),'ByteArray #[97 90 99]');
  assert.equal(run("^ [FileStream read: 'mixed' type: 'binary'] on: FileError do: [:e | 79]"),79);
  assert.equal(run("^ [FileStream write: 'mixed' mode: #readWrite] on: FileError do: [:e | 80]"),80);
  const str=run("| f | f := WriteStream on: ''. f nextPut: $a; cr; tab; space; nextPut: $b; flush. ^ f contents");
  assert.equal(h.fetch(str).text,'a\n\t b');
  const first=run("| f | f := ReadStream on: ('first' , Character cr asString , Character lf asString , 'second'). f nextLine. ^ f nextLine");
  assert.equal(h.fetch(first).text,'second');
  assert.equal(run("| f | f := ReadStream on: 'x'. f setToEnd. ^ f isEmpty"),h.false);
  assert.throws(()=>run("| f | f := ReadStream on: 'x'. f close. ^ f next"),/closed/);
});
check('A6.1 browser adapter preserves bytes, image migration and conflicts with stale writers', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  const api=context.ST80A4b.externalFiles, bytes=values=>vm.runInContext('new Uint8Array('+JSON.stringify(values)+')',context);
  api.importBytes(h,'test.bin',bytes([0,255,13,10]));
  assert.equal(h.display(run("^ (FileStream read: 'test.bin' type: #binary) contents")),'ByteArray #[0 255 13 10]');
  h.setGlobal('ExternalWriter',run("^ FileStream write: 'test.bin' mode: #append check: true type: #binary"));
  run('^ ExternalWriter nextPut: 3');
  api.importBytes(h,'test.bin',bytes([9,8]));
  assert.equal(run('^ [ExternalWriter close] on: FileError do: [:e | 81]'),81);
  assert.deepEqual([...api.exportBytes(h,'test.bin')],[9,8]);
  assert.throws(()=>api.importBytes(h,'test.bin',bytes(Array(4097).fill(0))),/at most/);
  const reopened=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.deepEqual([...api.exportBytes(reopened,'test.bin')],[9,8]);
});

check('A6.2 Float analysis operations preserve the receiver representation', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  const operations=[
    ['0.0','sin',0],['0.0','cos',1],['0.0','tan',0],['0.0','arcTan',0],
    ['1.0','arcSin',Math.PI/2],['-1.0','arcCos',Math.PI],
    ['180.0','degreesToRadians',Math.PI],['1.0','radiansToDegrees',180/Math.PI],
    ['1.0','exp',Math.E],['1.0','ln',0],['64.0','log: 2',6],['0.25','log: 0.5d0',2]
  ];
  for(const [v,selector,expected] of operations)for(const [suffix,type] of [['e0','Float'],['d0','FloatD']]){
    const ref=run('^ '+v+suffix+' '+selector);
    assert.equal(h.classOf(ref),type);
    const ideal=type==='Float'?Math.fround(expected):expected;
    assert(Math.abs(h.fetch(ref).numeric-ideal)<=Math.abs(ideal)*Number.EPSILON*4);
  }
  assert.equal(run('^ 1000.0d0 floorLog: 10'),3);
  assert.equal(run('^ 0.125d0 floorLog: 2'),-3);
  assert.equal(run('^ 999.0d0 floorLog: 10'),2);
  assert.equal(run('^ 0.0 respondsTo: #sin'),h.true);
  assert.equal(run('^ 0 respondsTo: #sin'),h.false);
  assert.equal(h.fetch(run('^ 0.0 perform: #cos')).numeric,1);
  assert.throws(()=>run('^ 2.0 arcCos'),/between -1 and 1/);
  assert.throws(()=>run('^ 0.0 ln'),/positive receiver/);
  assert.throws(()=>run('^ 1.0 log: 1'),/valid base/);
  assert.throws(()=>run('^ 0.25 floorLog: 0.5'),/greater than 1/);
  assert.throws(()=>run('^ 100.0 exp'),/overflow/);
});
check('A6.2 Float characterization reports numeric bounds by representation', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [global,type,precision,minNormal,minSub,max] of [
    ['Float','Float',24,2**-126,2**-149,3.4028234663852886e38],
    ['FloatE','Float',24,2**-126,2**-149,3.4028234663852886e38],
    ['FloatD','FloatD',53,2**-1022,Number.MIN_VALUE,Number.MAX_VALUE],
    ['FloatQ','FloatD',53,2**-1022,Number.MIN_VALUE,Number.MAX_VALUE],
  ]){
    assert.equal(run('^ '+global+' precision'),precision);
    assert.equal(run('^ '+global+' denormalized'),h.true);
    assert.equal(run('^ '+global+' respondsTo: #fminDenormalized'),h.true);
    for(const [selector,value] of [['fmin',minNormal],['fminNormalized',minNormal],['fminDenormalized',minSub],['fmax',max]]){
      const result=run('^ '+global+' perform: #'+selector);
      assert.equal(h.classOf(result),type);
      assert.equal(h.fetch(result).numeric,value);
      h.setGlobal('Saved'+global+selector,result);
    }
  }
  const after=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(after.fetch(a4bRun(after,'^ SavedFloatQfminDenormalized')).numeric,Number.MIN_VALUE);
});
check('A6.2 Character case tests use Unicode letters and the draft decimal digit set', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [source,result] of [['$9 isDigit',true],['$١ isDigit',false],['$é isLetter',true],['$é isLowercase',true],
    ['$É isUppercase',true],['$é isAlphaNumeric',true],['$🍎 isAlphaNumeric',false],['$é respondsTo: #asUppercase',true]]){
    assert.equal(run('^ '+source),result?h.true:h.false);
  }
  assert.equal(h.fetch(run('^ $é asUppercase asString')).text,'É');
  assert.equal(h.fetch(run('^ $É asLowercase asString')).text,'é');
  assert.equal(h.fetch(run('^ $ß asUppercase asString')).text,'ß');
});
check('A6.2 every draft section 5.2 standard global is bound', () => {
  const h=new VM.ImageHeap();
  const names='Array Bag ByteArray DateAndTime Dictionary Duration Error Exception FileStream Float FloatD FloatE FloatQ Fraction IdentityDictionary Interval MessageNotUnderstood Notification Object OrderedCollection ReadStream ReadWriteStream Set SortedCollection String TimeLocal Transcript Warning WriteStream ZeroDivide'.split(' ');
  for(const name of names){
    assert(h.associations.has(name),name);
    assert.notEqual(h.readAssociation(h.associations.get(name)),h.nil,name);
  }
  return names.length+' binding checks';
});

check('A6.3 unqualified Float literals choose the narrowest exact representation', () => {
  const h=new VM.ImageHeap(),run=source=>a4bRun(h,source);
  for(const [literal,kind] of [['0.125','Float'],['0.10','FloatD'],['-0.125','Float'],['-0.1','FloatD'],
    ['16777216.0','Float'],['16777217.0','FloatD'],['0.1e0','Float'],['0.125d0','FloatD'],['0.125q0','FloatD'],
    ['1'+'0'.repeat(39)+'.0','FloatD']]){
    assert.equal(h.classOf(run('^ '+literal)),kind,literal);
  }
  const exact='0.'+(5n**149n).toString().padStart(149,'0');
  assert.equal(h.classOf(run('^ '+exact)),'Float');
  assert.equal(h.fetch(run('^ '+exact)).numeric,2**-149);
  const array=run('^ #(0.125 0.10 -0.1 0.1e0)');
  assert.deepEqual(Array.from(h.fetch(array).indexed,v=>h.classOf(v)),['Float','FloatD','FloatD','Float']);
  h.setGlobal('A63SavedFloat',run('^ 0.1'));
  const after=IO.restore(JSON.parse(JSON.stringify(IO.save(h)))).heap;
  assert.equal(after.classOf(a4bRun(after,'^ A63SavedFloat')),'FloatD');
});
check('A6.3 class and pool variable draft minimums work through SIF export and reimport', () => {
  const vars=Array.from({length:127},(_,i)=>'Shared'+i).join(' ');
  const defs=Array.from({length:1000},(_,i)=>"BoundaryPool variable: 'Slot"+i+"'!").join('\n');
  const source=["Smalltalk interchangeVersion: '1.0'!", "Pool named: 'BoundaryPool'!",defs,
    "Class named: 'BoundaryVars' superclass: 'Object' indexedInstanceVariables: #'none' instanceVariableNames: '' classVariableNames: '"+vars+"' sharedPools: 'BoundaryPool' classInstanceVariableNames: ''!",
    "BoundaryPool initializerFor: 'Slot999'! 23!",
    "BoundaryVars initializer! Shared126 := 19!",
    "BoundaryVars classMethod! result\n ^ Shared126 + Slot999!"].join('\n');
  const program=context.ST80SIF.open(source);
  assert.equal(program.evaluate('BoundaryVars result'),'42');
  assert.equal(context.ST80SIF.open(program.export()).evaluate('BoundaryVars result'),'42');
});
check('A6.3 draft argument, temporary, binary selector and scaled precision boundaries', () => {
  const h=new VM.ImageHeap(),cc=new CC.MethodCompiler(h),run=source=>a4bRun(h,source);
  const args=Array.from({length:15},(_,i)=>'arg'+i),temps=Array.from({length:15},(_,i)=>'temp'+i).join(' ');
  const method=args.map((name,i)=>'k'+i+': '+name).join(' ');
  cc.compile('Object',method+'\n | '+temps+' | temp14 := arg14. ^ temp14',{install:true});
  assert.equal(run('^ self '+args.map((_,i)=>'k'+i+': '+i).join(' ')),14);
  const block='[:'+args.join(' :')+' | | '+temps+' | temp14 := arg14. temp14]';
  assert.equal(run('^ '+block+' valueWithArguments: #(0 1 2 3 4 5 6 7 8 9 10 11 12 13 14)'),14);
  cc.compile('Object','++ other\n ^ other',{install:true});
  assert.equal(run('^ self ++ 42'),42);
  const decimal='0.123456789012345678901234567891s30';
  assert.equal(h.display(run('^ '+decimal)),decimal);
});
if (process.argv.includes('--emit-sif-evidence')) {
  for(const name of ['SifLedger','SifIndexed']){
    const source=fs.readFileSync(path.join(root,'samples',name+'.sif'),'utf8');
    fs.writeFileSync(path.join(root,'reports',name+'.export.sif'),context.ST80SIF.open(source).export());
  }
}

check('Final migrates an accepted A6.3 native image with FloatD and staged binary data', () => {
  const image=fixture('Accepted_A6_3_Native','st80image');
  assert.equal(image.studioVersion,'1.2.0-rc.1.3');
  const first=IO.restore(image).heap, saved=IO.save(first);
  assert.equal(saved.studioVersion,'1.2.0');
  const second=IO.restore(JSON.parse(JSON.stringify(saved))).heap;
  assert.equal(second.classOf(a4bRun(second,'^ SavedNumber')),'FloatD');
  assert.equal(second.fetch(a4bRun(second,'^ SavedNumber')).numeric,0.1);
  assert.deepEqual([...context.ST80A4b.externalFiles.exportBytes(second,'accepted-a63.bin')],[0,13,255]);
});
check('Final migrates an accepted RC2 native image with FloatD and staged binary data', () => {
  const image=fixture('Accepted_RC2_Native','st80image');
  assert.equal(image.studioVersion,'1.2.0-rc.2');
  const first=IO.restore(image).heap, saved=IO.save(first);
  assert.equal(saved.studioVersion,'1.2.0');
  const second=IO.restore(JSON.parse(JSON.stringify(saved))).heap;
  assert.equal(second.classOf(a4bRun(second,'^ SavedNumber')),'FloatD');
  assert.equal(second.fetch(a4bRun(second,'^ SavedNumber')).numeric,0.1);
  assert.deepEqual([...context.ST80A4b.externalFiles.exportBytes(second,'accepted-a63.bin')],[0,13,255]);
});

async function writeReport() {
  for (const result of results) result.detail = (await result.detail) ?? null;
  const report = {version: "1.2.0", phase: "Final", node: process.version, inlineScriptsSyntaxChecked: modules.length, passed: results.length, results};
  fs.writeFileSync(path.join(root, 'reports', 'Final_Runtime.json'), JSON.stringify(report, null, 2) + '\n');
  console.log(JSON.stringify(report, null, 2));
}
writeReport().catch(error => { console.error(error); process.exitCode = 1; });
