!studio-package 1
!manifest {"id":"studio.samples.take-away","version":"1.0.0","title":"Take Away","requires":{"studio":"1.1","classes":["Object"]}}
!class TakeAway < Object | remaining winner
!method instance
reset
  remaining := 15. winner := 0.
  ^ remaining
!
!method instance
take: n
  | reply |
  winner ~= 0 ifTrue: [ ^ winner ].
  n < 1 ifTrue: [ ^ remaining ]. n > 3 ifTrue: [ ^ remaining ].
  n > remaining ifTrue: [ ^ remaining ].
  remaining := remaining - n.
  remaining = 0 ifTrue: [ winner := 1. ^ remaining ].
  reply := 4 - n.
  reply > remaining ifTrue: [ reply := remaining ].
  remaining := remaining - reply.
  remaining = 0 ifTrue: [ winner := 2 ].
  ^ remaining
!
!method instance
remaining
  ^ remaining
!
!method instance
winner
  ^ winner
!
!method class
start
  | app |
  app := self new. app reset.
  ^ app
!
!startup TakeAway start
