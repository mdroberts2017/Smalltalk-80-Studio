!studio-package 1
!manifest {"id":"studio.examples.guessing-game","version":"1.0.0","title":"Guessing Game","requires":{"studio":"1.1","classes":["Object"]}}
!class GuessingGame < Object | secret tries
!method instance
initialize
  secret := 7.
  tries := 0.
  ^ self
!
!method instance
guess: aNumber
  tries := tries + 1.
  aNumber < secret ifTrue: [ ^ 'Higher' ].
  aNumber > secret ifTrue: [ ^ 'Lower' ].
  ^ 'Correct!'
!
!method instance
attempts
  ^ tries
!
!method instance
restart
  secret := 7.
  tries := 0.
  ^ self
!
!method class
start
  ^ self new initialize
!
!startup GuessingGame start
